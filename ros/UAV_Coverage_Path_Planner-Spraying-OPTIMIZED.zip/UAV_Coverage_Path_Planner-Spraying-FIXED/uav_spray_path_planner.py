"""
============================================================================
 UAV Coverage Path Planner - Full-Field Spraying Edition
============================================================================
Reads a field boundary traced in Google Earth (KML), plans a clean
boustrophedon spray pattern over it, and exports a flyable mission.

The mission always has exactly three legs, and they are drawn the same way
everywhere (preview image and Google Earth):

    INITIAL  black square   the drone's position - you type it in when asked
    |
    |  Leg 1  GREEN         transit out, spray OFF
    v
    START    RED dot        spraying begins - chosen by the planner
    |
    |  Leg 2  BLUE          the coverage pass, spray ON
    v
    GOAL     YELLOW dot     spraying ends - chosen by the planner
    |
    |  Leg 3  GREEN         transit home, spray OFF - the straight, shortest
    v                       line back, even if it crosses the field
    INITIAL

Nothing about the mission is hard-coded. You give the program a field and the
drone's position; it decides the START, the GOAL and the whole path, picking
the combination that makes the complete trip (leg 1 + spraying + leg 3)
shortest. Every leg is written out as GPS coordinates for the drone to follow.

Field boundary is drawn in BLACK and nothing else uses black, so the
boundary can never be mistaken for the flight path.

Outputs (in outputs/):
    full_path_gps.csv          the WHOLE trip INITIAL -> START -> ... -> GOAL ->
                               INITIAL, a GPS point every PATH_STEP_M, so the
                               drone always has a coordinate to compare against
    spray_path.kml             the mission, colour-coded, for Google Earth
    waypoints_gps.txt          GPS waypoint list in flight order, with a LEG
                               column so the controller knows where to spray
    leg1_initial_to_start.csv  GPS coordinates: drone position -> START
    leg2_start_to_goal.csv     GPS coordinates: START -> GOAL (spray ON/OFF)
    leg3_goal_to_initial.csv   GPS coordinates: GOAL -> drone position
    drone_and_spray_specs.txt  parameters used + mission summary
    path_preview.png           preview image
    path_animation.gif         animation of the drone flying the whole mission

All settings live in config.py.
============================================================================
"""

import os
import re
from math import ceil

import matplotlib
import matplotlib.pyplot as plt

import config
import geometry as g
import coverage as cv
import kml_writer
import path_animation
import verify
from geo_utils import LocalProjector

if not config.SHOW_PLOTS:
    matplotlib.use("Agg")


# ---------------------------------------------------------------------------
# colours - kept identical between the preview image and the KML
# ---------------------------------------------------------------------------
C_BOUNDARY = "#000000"   # field boundary        - black
C_TRANSIT = "#00b050"    # legs 1 and 3          - green
C_SPRAY = "#1f5fd0"      # leg 2, the spraying   - blue
C_INITIAL = "#000000"    # launch & land pad     - black square
C_START = "#e00000"      # spraying begins       - red
C_GOAL = "#ffd400"       # spraying ends         - yellow
C_REPOSITION = "#ff8000"  # in-field move, pump off - orange


# ============================================================================
# 0) UPLOAD THE FIELD / SHOW THE RESULT
# ============================================================================
def prompt_for_field_file(default_path):
    print("=" * 62)
    print(" STEP 1: UPLOAD YOUR FIELD")
    print("=" * 62)
    print("Choose the .kml file you exported from Google Earth (the polygon")
    print("traced around your field).")

    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        print("\nOpening a file-upload window...")
        chosen = filedialog.askopenfilename(
            title="Upload your field boundary (.kml)",
            filetypes=[("KML files", "*.kml"), ("All files", "*.*")],
        )
        root.destroy()
        if chosen:
            print(f"Field uploaded: {chosen}")
            return chosen
        print("Nothing chosen in the window - falling back to typing a path.")
    except Exception:
        pass

    prompt = (f"\nPath to your field .kml "
              f"[Enter = use '{default_path}']: ")
    try:
        entered = input(prompt).strip().strip('"').strip("'")
    except EOFError:
        entered = ""
    chosen = entered or default_path
    print(f"Field uploaded: {chosen}")
    return chosen


def _parse_lat_lon(text):
    """Turn what the user typed into (lat, lon) in decimal degrees.

    Accepts '23.2495, 77.5263', '23.2495 77.5263', '-17.83 31.05' and the
    hemisphere-letter style '17.83 S, 31.05 E'. Returns None if it cannot
    be read as exactly one latitude and one longitude.
    """
    if any(ch in text for ch in ("\u00b0", "'", '"')):
        return None          # degrees-minutes-seconds - ask for decimal instead
    nums = re.findall(r"[-+]?\d+(?:\.\d+)?", text)
    letters = re.findall(r"[NSEWnsew]", text)
    if len(nums) != 2:
        return None
    lat, lon = float(nums[0]), float(nums[1])
    # 'S' / 'W' mean negative; only honoured when the letters are given
    # in the same order as the numbers (lat first, then lon)
    if len(letters) == 2:
        if letters[0].upper() in "SN" and letters[1].upper() in "EW":
            if letters[0].upper() == "S":
                lat = -abs(lat)
            if letters[1].upper() == "W":
                lon = -abs(lon)
        else:
            return None
    elif letters:
        return None
    return lat, lon


def prompt_for_drone_position(field_lonlat, default_lonlat=None):
    """Ask where the drone is. This is INITIAL: where it takes off from and
    where it comes back to. Returns (lon, lat).

    `default_lonlat` comes from a pin named INITIAL in the field's KML, if
    there is one - press Enter to accept it.
    """
    print()
    print("=" * 62)
    print(" STEP 2: WHERE IS THE DRONE?")
    print("=" * 62)
    print("Enter the drone's GPS position in decimal degrees, latitude first:")
    print("    e.g.  23.2495, 77.5263      or      -17.8252, 31.0335")
    print("The drone takes off from here and returns here at the end.")
    if default_lonlat:
        print(f"(A pin named INITIAL was found in your KML: "
              f"{default_lonlat[1]:.6f}, {default_lonlat[0]:.6f} - press Enter to use it.)")

    lon_c = sum(p[0] for p in field_lonlat) / len(field_lonlat)
    lat_c = sum(p[1] for p in field_lonlat) / len(field_lonlat)
    probe = LocalProjector(lat_c, lon_c)

    for _ in range(5):
        try:
            text = input("\nDrone position (latitude, longitude): ").strip()
        except EOFError:
            text = ""
        if not text:
            if default_lonlat:
                return default_lonlat
            print("  A position is required - the planner needs to know where the drone is.")
            continue
        parsed = _parse_lat_lon(text)
        if parsed is None:
            print("  Could not read that. Type two decimal numbers: latitude, longitude.")
            continue
        lat, lon = parsed
        if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
            print("  That is not a valid position (latitude is -90..90, longitude -180..180). "
                  "Did you type longitude first?")
            continue
        x, y = probe.to_xy(lon, lat)
        far_m = (x * x + y * y) ** 0.5
        if far_m > 5000:
            print(f"  Warning: that is {far_m/1000:.1f} km from the field.")
            try:
                ok = input("  Use it anyway? [y/N]: ").strip().lower()
            except EOFError:
                ok = ""
            if ok not in ("y", "yes"):
                continue
        return (lon, lat)

    raise SystemExit("No valid drone position entered - stopping.")


def display_worked_field(png_path):
    print("\n" + "=" * 62)
    print(" YOUR WORKED FIELD")
    print("=" * 62)
    print(f"Preview image: {os.path.abspath(png_path)}")
    import platform
    import subprocess
    try:
        system = platform.system()
        if system == "Windows":
            os.startfile(png_path)  # type: ignore[attr-defined]
        elif system == "Darwin":
            subprocess.run(["open", png_path], check=False)
        else:
            subprocess.run(["xdg-open", png_path], check=False)
    except Exception:
        print("(Could not open a viewer here - open the file above manually.)")


# ============================================================================
# 1) READ THE KML
# ============================================================================
def extract_polygon_from_kml(kml_file_path):
    """Largest polygon ring in the file, as a list of (lon, lat)."""
    with open(kml_file_path, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read()

    rings = []
    for block in re.findall(r"<coordinates>(.*?)</coordinates>", text, re.S):
        pairs = re.findall(r"(-?\d+\.?\d*),(-?\d+\.?\d*)", block)
        if len(pairs) > 2:
            rings.append([(float(lon), float(lat)) for lon, lat in pairs])

    if not rings:
        raise ValueError(
            f"No polygon found in '{kml_file_path}'. Make sure the file "
            "contains the shape you traced around your field."
        )
    return g.strip_ring(max(rings, key=lambda r: abs(g.signed_area(r))))


def extract_named_points_from_kml(kml_file_path):
    """OPTIONAL: let the user MARK the three mission points directly in
    Google Earth instead of typing coordinates into config.py.

    Optional: drop a placemark (pin) on the map, name it INITIAL, and export
    it in the same KML as the field - it is then offered as the default when
    the program asks for the drone's position. (START and GOAL pins are
    ignored: the planner chooses those itself.)
    """
    with open(kml_file_path, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read()

    found = {}
    for block in re.findall(r"<Placemark\b.*?</Placemark>", text, re.S):
        if "<Point" not in block:
            continue
        name_m = re.search(r"<name>(.*?)</name>", block, re.S)
        coord_m = re.search(r"<coordinates>(.*?)</coordinates>", block, re.S)
        if not name_m or not coord_m:
            continue
        name = name_m.group(1).strip().lower()
        pair = re.findall(r"(-?\d+\.?\d*),(-?\d+\.?\d*)", coord_m.group(1))
        if not pair:
            continue
        lon, lat = float(pair[0][0]), float(pair[0][1])
        if any(w in name for w in ("initial", "home", "pad", "launch")):
            found["initial"] = (lon, lat)
        elif "start" in name:
            found["start"] = (lon, lat)
        elif any(w in name for w in ("goal", "finish", "end")):
            found["goal"] = (lon, lat)
    return found


# ============================================================================
# 2) TRANSIT LEGS  (pad <-> field, without flying over the crop)
# ============================================================================
def plan_transit(pad_xy, field_point_xy, field_poly, ring_poly, avoid_field):
    """Route from the drone's position out to a point on the field (leg 1).

    (The way home, leg 3, does not use this: it is always the straight,
    shortest line from GOAL back to the drone.)

    If `avoid_field` is on, the route goes AROUND the outside of the field
    and only enters at the nearest boundary point. That is what stops the
    transit leg from slicing diagonally across the spray pattern - the long
    stray line that used to cut through the middle of the generated path.
    """
    if g.dist(pad_xy, field_point_xy) < 1e-6:
        return [pad_xy]

    if not avoid_field:
        return [pad_xy, field_point_xy]

    if g.point_in_polygon(pad_xy, field_poly):
        # pad is inside the field - just stay inside and go straight there
        return g.dedupe_consecutive(g.shortest_path_inside(pad_xy, field_point_xy, field_poly))

    entry = g.nearest_point_on_boundary(field_point_xy, field_poly)

    if g.segment_outside_polygon(pad_xy, entry, field_poly, tol=0.05):
        route = [pad_xy, entry]
    else:
        q0, s0 = g.project_onto_ring(pad_xy, ring_poly)
        q1, s1 = g.project_onto_ring(entry, ring_poly)
        route = [pad_xy, q0] + g.walk_ring(ring_poly, s0, s1) + [q1, entry]

    route.append(field_point_xy)
    return g.dedupe_consecutive(route)


# ============================================================================
# 3) OUTPUT FILES
# ============================================================================
def densify(points, spacing_m):
    """Add evenly spaced intermediate points along every straight stretch, so
    no hop is longer than `spacing_m`. The original points (corners, ends)
    are all kept exactly; spacing_m <= 0 returns the points unchanged."""
    if spacing_m <= 0 or len(points) < 2:
        return list(points)
    out = [points[0]]
    for a, b in zip(points, points[1:]):
        n = int(ceil(g.dist(a, b) / spacing_m - 1e-9))
        for k in range(1, n):
            t = k / n
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
        out.append(b)
    return out


def split_runs(points, flags):
    """Break a path into consecutive runs of equal spray state, so each run
    can be drawn (and flown) as one continuous ON or OFF stretch."""
    runs = []
    for i in range(1, len(points)):
        on = bool(flags[i])
        if runs and runs[-1][0] == on:
            runs[-1][1].append(points[i])
        else:
            runs.append((on, [points[i - 1], points[i]]))
    return runs


def write_waypoints(path, legs_lonlat, proj):
    """legs_lonlat: list of (leg_name, flags, [(lon,lat), ...]) where flags[i]
    is the spray state of the leg INTO point i."""
    rows = []
    for leg_name, flags, pts in legs_lonlat:
        for i, (lon, lat) in enumerate(pts):
            spray_on = bool(flags[i]) if i < len(flags) else False
            if rows and abs(rows[-1][1] - lat) < 1e-12 and abs(rows[-1][2] - lon) < 1e-12:
                continue
            rows.append((leg_name, lat, lon, spray_on))

    lines = [
        "# UAV SPRAY MISSION - GPS WAYPOINTS",
        "# Columns: WP, LATITUDE, LONGITUDE, SPRAY, LEG, CUM_DIST_M",
        "#   SPRAY = ON  -> pump running on the way TO this waypoint",
        "#   SPRAY = OFF -> transit only",
        "#",
    ]

    cum = 0.0
    prev = None
    for i, (leg, lat, lon, spray_on) in enumerate(rows):
        if prev is not None:
            dlat = (lat - prev[0]) * proj.m_per_deg_lat
            dlon = (lon - prev[1]) * proj.m_per_deg_lon
            cum += (dlat ** 2 + dlon ** 2) ** 0.5
        prev = (lat, lon)
        lines.append(
            f"{i+1},{lat:.7f},{lon:.7f},"
            f"{'ON' if spray_on else 'OFF'},{leg},{cum:.1f}"
        )

    lines += [
        "#",
        f"# Total waypoints : {len(rows)}",
        f"# Total distance  : {cum:.1f} m",
    ]
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return len(rows), cum


def write_leg_file(path, pts_lonlat, flags, proj):
    """One leg of the mission as a plain CSV of GPS coordinates, ready to be
    loaded into a flight controller. flags[i] is the spray state of the leg
    INTO point i (the first point is where the drone already is, so OFF)."""
    rows = []
    for i, (lon, lat) in enumerate(pts_lonlat):
        on = bool(flags[i]) if i < len(flags) else False
        if rows and abs(rows[-1][0] - lat) < 1e-12 and abs(rows[-1][1] - lon) < 1e-12:
            rows[-1] = (lat, lon, rows[-1][2] or on)
            continue
        rows.append((lat, lon, on))

    lines = ["WP,LATITUDE,LONGITUDE,SPRAY,CUM_DIST_M"]
    cum, prev = 0.0, None
    for i, (lat, lon, on) in enumerate(rows):
        if prev is not None:
            dlat = (lat - prev[0]) * proj.m_per_deg_lat
            dlon = (lon - prev[1]) * proj.m_per_deg_lon
            cum += (dlat ** 2 + dlon ** 2) ** 0.5
        prev = (lat, lon)
        lines.append(f"{i+1},{lat:.7f},{lon:.7f},{'ON' if on else 'OFF'},{cum:.1f}")
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return len(rows), cum


def densify_flagged(points, flags, spacing_m):
    """Like densify(), but for a path with a spray flag per point. Every point
    added inside a stretch takes the spray state of that stretch (flags[i] is
    the state of the leg INTO point i)."""
    if spacing_m <= 0 or len(points) < 2:
        return list(points), list(flags)
    out, out_f = [points[0]], [False]
    for i in range(1, len(points)):
        a, b = points[i - 1], points[i]
        n = int(ceil(g.dist(a, b) / spacing_m - 1e-9))
        for k in range(1, n):
            t = k / n
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
            out_f.append(bool(flags[i]))
        out.append(b)
        out_f.append(bool(flags[i]))
    return out, out_f


def write_full_path(path, out_xy, spray_xy, spray_flags, home_xy, step_m, to_lonlat):
    """The WHOLE trip as one list of GPS points, INITIAL -> START -> ... ->
    GOAL -> INITIAL, with a point at least every `step_m` metres along it.

    The drone compares its own GPS position with these points to stay on the
    path, so every stretch - transit and spraying alike - is broken into
    small steps, and the corners of the path are kept exactly.

    Columns: STEP, LATITUDE, LONGITUDE, SPRAY, LEG, POINT, CUM_DIST_M
      SPRAY  ON/OFF  pump state on the way TO this point
      LEG    TRANSIT_OUT / SPRAYING / TRANSIT_HOME
      POINT  INITIAL / START / GOAL on those rows, empty elsewhere
      CUM_DIST_M  distance flown along the path up to this point
    Returns (number of points, total distance in metres).
    """
    out_pts = densify(out_xy, step_m)
    sp_pts, sp_flags = densify_flagged(spray_xy, spray_flags, step_m)
    home_pts = densify(home_xy, step_m)

    pts, flags, legs = [], [], []
    for p in out_pts:
        pts.append(p); flags.append(False); legs.append("TRANSIT_OUT")
    start_idx = len(pts) - 1
    for p, f in zip(sp_pts[1:], sp_flags[1:]):
        pts.append(p); flags.append(f); legs.append("SPRAYING")
    goal_idx = len(pts) - 1
    for p in home_pts[1:]:
        pts.append(p); flags.append(False); legs.append("TRANSIT_HOME")

    marks = {}
    for idx, name in ((0, "INITIAL"), (start_idx, "START"),
                      (goal_idx, "GOAL"), (len(pts) - 1, "INITIAL")):
        if name not in marks.setdefault(idx, []):
            marks[idx].append(name)

    lines = ["STEP,LATITUDE,LONGITUDE,SPRAY,LEG,POINT,CUM_DIST_M"]
    cum = 0.0
    for i, p in enumerate(pts):
        if i:
            cum += g.dist(pts[i - 1], p)
        lon, lat = to_lonlat(*p)
        lines.append(f"{i},{lat:.7f},{lon:.7f},{'ON' if flags[i] else 'OFF'},"
                     f"{legs[i]},{'/'.join(marks.get(i, []))},{cum:.2f}")
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return len(pts), cum


def write_specs(path, spacing_m, route, total_distance_m, spray_distance_m,
                num_waypoints, crossings, stats, mission):
    lines = [
        "============================================================",
        " PATH PARAMETERS USED",
        "============================================================",
        "",
        "-- Spray swath --",
        f"Spray swath width (ground)  : {config.SPRAY_SWATH_WIDTH_M:.2f} m",
        f"Overlap between passes      : {config.SPRAY_OVERLAP_PCT*100:.0f} %",
        f"Resulting line spacing      : {spacing_m:.2f} m  (= swath x (1 - overlap))",
        f"Adjusted spacing used       : {route['spacing_min_m']:.3f} - {route['spacing_max_m']:.3f} m  "
        "(fitted so the lines land exactly on the boundary offset)",
        f"Boundary safety margin      : {config.BOUNDARY_SAFETY_MARGIN_M:.2f} m",
        "",
        "-- Generated pattern --",
        f"Sweep direction             : {route['angle_deg']:.1f} deg "
        "(0 = lines run East-West, 90 = North-South)",
        f"Number of spray passes      : {route['num_passes']}",
        f"Boustrophedon cells         : {route['num_cells']}",
        f"Path self-crossings         : {crossings}   (0 = fully clean path)",
        "",
        "-- Measured coverage (sampled check on the finished path) --",
        f"Field covered               : {stats['covered_pct']:.2f} %",
        f"Over-sprayed (3+ passes)    : {stats['triple_pct']:.2f} %",
        f"Average passes per point    : {stats['mean_passes']:.2f}",
        f"Sample grid                 : {stats['step_m']:.2f} m "
        f"({stats['samples']} points)",
        "",
        "-- Distance --",
        f"Total waypoints             : {num_waypoints}",
        f"Spraying distance (leg 2)   : {spray_distance_m:.1f} m",
        f"Total path length           : {total_distance_m:.1f} m",
        "",
        "-- Mission points (chosen by the planner, except INITIAL) --",
        f"INITIAL (drone position)    : {mission['initial'][1]:.7f}, {mission['initial'][0]:.7f}  (lat, lon - entered by you)",
        f"START (spraying begins)     : {mission['start'][1]:.7f}, {mission['start'][0]:.7f}  (lat, lon)",
        f"GOAL  (spraying ends)       : {mission['goal'][1]:.7f}, {mission['goal'][0]:.7f}  (lat, lon)",
        f"Leg 1  INITIAL -> START     : {mission['leg1_m']:.1f} m",
        f"Leg 2  START -> GOAL        : {mission['leg2_m']:.1f} m",
        f"Leg 3  GOAL -> INITIAL      : {mission['leg3_m']:.1f} m  (straight, shortest line)",
        "============================================================",
    ]
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")


# ============================================================================
# 4) PREVIEW IMAGE
# ============================================================================
def save_preview(field_xy, safe_xy, leg_out, spray, flags, leg_home,
                 initial_xy, start_xy, goal_xy, out_path, show):
    fig, ax = plt.subplots(figsize=(13, 8))

    fx, fy = zip(*g.close_ring(field_xy))
    ax.plot(fx, fy, color=C_BOUNDARY, lw=2.6, zorder=6, label="Field boundary")

    sx, sy = zip(*g.close_ring(safe_xy))
    ax.plot(sx, sy, color="#999999", lw=0.9, ls="--", zorder=2,
            label=f"Safety margin ({config.BOUNDARY_SAFETY_MARGIN_M:.2f} m)")

    shown_on = shown_off = False
    for on, run in split_runs(spray, flags):
        rx, ry = zip(*run)
        if on:
            ax.plot(rx, ry, color=C_SPRAY, lw=1.5, zorder=4,
                    label=None if shown_on else "Leg 2: spraying (START -> GOAL)")
            shown_on = True
        else:
            ax.plot(rx, ry, color=C_REPOSITION, lw=1.6, zorder=4,
                    label=None if shown_off else "Repositioning (pump off)")
            shown_off = True

    first = True
    for leg in (leg_out, leg_home):
        if len(leg) > 1:
            lx, ly = zip(*leg)
            ax.plot(lx, ly, color=C_TRANSIT, lw=3.0, zorder=5,
                    label="Legs 1 & 3: transit (no spray)" if first else None)
            first = False

    ax.scatter(*initial_xy, s=190, marker="s", facecolors="white",
               edgecolors=C_INITIAL, linewidths=2.4, zorder=9, label="INITIAL (launch & land)")
    ax.scatter(*start_xy, s=190, marker="o", c=C_START,
               edgecolors="black", linewidths=1.4, zorder=10, label="START (spray ON)")
    ax.scatter(*goal_xy, s=190, marker="o", c=C_GOAL,
               edgecolors="black", linewidths=1.4, zorder=10, label="GOAL (spray OFF)")

    for xy, txt, col in ((initial_xy, "INITIAL", C_INITIAL),
                         (start_xy, "START", C_START),
                         (goal_xy, "GOAL", "#9a7d00")):
        ax.annotate(txt, xy=xy, xytext=(9, 9), textcoords="offset points",
                    fontsize=10, fontweight="bold", color=col, zorder=11,
                    bbox=dict(boxstyle="round,pad=0.25", fc="white", ec=col, lw=1.1, alpha=0.9))

    ax.set_aspect("equal")
    ax.set_title("UAV Spray Coverage Path", fontsize=13, fontweight="bold")
    ax.set_xlabel("meters (east)")
    ax.set_ylabel("meters (north)")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.09), ncol=4, fontsize=9, framealpha=0.95)
    plt.tight_layout()

    if config.SAVE_PLOTS:
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
    if show:
        try:
            plt.show()
        except Exception:
            pass
    plt.close(fig)


# ============================================================================
# 5) MAIN
# ============================================================================
def main():
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)
    field_kml = prompt_for_field_file(config.INPUT_FIELD_KML)

    print(f"\nReading field boundary from '{field_kml}' ...")
    field_lonlat = extract_polygon_from_kml(field_kml)
    marked = extract_named_points_from_kml(field_kml)
    if "start" in marked or "goal" in marked:
        print("Note: START / GOAL pins in the KML are ignored - "
              "the planner chooses the best start and goal itself.")

    initial_lonlat = prompt_for_drone_position(field_lonlat, marked.get("initial"))

    projector = LocalProjector.from_polygon(field_lonlat)
    field_xy = g.ensure_ccw([projector.to_xy(lon, lat) for lon, lat in field_lonlat])
    field_area = g.area(field_xy)
    print(f"\nField area: {field_area:.1f} m^2 ({field_area/10000:.3f} ha)")

    spacing = config.SPRAY_SWATH_WIDTH_M * (1 - config.SPRAY_OVERLAP_PCT)
    if not (0 <= config.SPRAY_OVERLAP_PCT < 1):
        raise ValueError("SPRAY_OVERLAP_PCT must be >= 0 and < 1.")
    margin = config.BOUNDARY_SAFETY_MARGIN_M
    print(f"Spray line spacing: {spacing:.2f} m | Boundary safety margin: {margin:.2f} m")

    safe_xy = g.inset_polygon(field_xy, margin)
    ring_xy = g.outset_polygon(field_xy, max(margin, config.TRANSIT_CLEARANCE_M))

    initial_xy = projector.to_xy(*initial_lonlat)

    # Leg 1 is measured exactly as it will be flown, so the planner can weigh
    # "start over there" against "start over here" on the real distances.
    leg1_cache = {}

    def leg_out_for(start_xy):
        key = (round(start_xy[0], 4), round(start_xy[1], 4))
        if key not in leg1_cache:
            leg1_cache[key] = plan_transit(initial_xy, start_xy, field_xy, ring_xy,
                                           config.TRANSIT_AVOID_FIELD)
        return leg1_cache[key]

    def leg_out_cost(start_xy):
        return g.polyline_length(leg_out_for(start_xy))

    print("Planning coverage (choosing the best start, goal and path) ...")
    route = cv.plan_coverage(
        safe_xy, spacing, initial_xy, leg_out_cost,
        mode=config.SWEEP_MODE, fixed_angle_deg=config.SWEEP_ANGLE_DEG,
        turn_penalty_m=config.TURN_PENALTY_M,
        field_poly=field_xy, swath=config.SPRAY_SWATH_WIDTH_M,
    )
    spray = route["points"]
    flags = route["flags"]
    start_xy, goal_xy = route["start"], route["goal"]
    crossings = g.count_self_crossings(spray)
    print(f"  sweep direction : {route['angle_deg']:.1f} deg")
    print(f"  spray passes    : {route['num_passes']} in {route['num_cells']} cell(s)")
    print(f"  line spacing    : {route['spacing_min_m']:.3f} - {route['spacing_max_m']:.3f} m "
          f"(fitted to the field, never more than {spacing:.2f} m)")
    print(f"  self-crossings  : {crossings}")

    stats = verify.verify_coverage(field_xy, spray, flags, config.SPRAY_SWATH_WIDTH_M)
    print(f"  field covered   : {stats['covered_pct']:.2f} %")
    print(f"  over-sprayed    : {stats['triple_pct']:.2f} % (3+ passes)")

    # Leg 1: INITIAL -> START, as configured (around the field or straight).
    leg_out = leg_out_for(start_xy)
    # Leg 3: GOAL -> INITIAL is ALWAYS the straight, shortest line, even if
    # it crosses the field - nothing is gained by detouring on the way home.
    leg_home = g.dedupe_consecutive([goal_xy, initial_xy])

    # Corner-only copies of both transit legs, for the full-path file below.
    leg_out_raw, leg_home_raw = leg_out, leg_home

    # Break the long straight stretches of both transit legs into short hops,
    # so the drone has a GPS point to match every few meters.
    leg_out = densify(leg_out, config.TRANSIT_WAYPOINT_SPACING_M)
    leg_home = densify(leg_home, config.TRANSIT_WAYPOINT_SPACING_M)

    to_ll = lambda pts: [projector.to_lonlat(x, y) for x, y in pts]

    kml_writer.write_mission_kml(
        os.path.join(config.OUTPUT_DIR, "spray_path.kml"),
        to_ll(g.close_ring(field_xy)),
        to_ll(leg_out),
        [(on, to_ll(pts)) for on, pts in split_runs(spray, flags)],
        to_ll(leg_home),
        projector.to_lonlat(*initial_xy),
        projector.to_lonlat(*start_xy),
        projector.to_lonlat(*goal_xy),
        summary=(f"{route['num_passes']} passes, {route['angle_deg']:.0f} deg sweep, "
                 f"{spacing:.2f} m spacing."),
    )

    n_wp, total_m = write_waypoints(
        os.path.join(config.OUTPUT_DIR, "waypoints_gps.txt"),
        [("TRANSIT_OUT", [False] * len(leg_out), to_ll(leg_out)),
         ("SPRAYING", flags, to_ll(spray)),
         ("TRANSIT_HOME", [False] * len(leg_home), to_ll(leg_home))],
        projector,
    )

    # The same three legs again, one file each, so the drone can be fed
    # exactly the GPS coordinates it must fly for each part of the mission.
    _, leg1_m = write_leg_file(
        os.path.join(config.OUTPUT_DIR, "leg1_initial_to_start.csv"),
        to_ll(leg_out), [False] * len(leg_out), projector)
    _, leg2_m = write_leg_file(
        os.path.join(config.OUTPUT_DIR, "leg2_start_to_goal.csv"),
        to_ll(spray), flags, projector)
    _, leg3_m = write_leg_file(
        os.path.join(config.OUTPUT_DIR, "leg3_goal_to_initial.csv"),
        to_ll(leg_home), [False] * len(leg_home), projector)

    # The whole trip, INITIAL -> START -> ... -> GOAL -> INITIAL, with a GPS
    # point every PATH_STEP_M so the drone always has a coordinate to compare
    # its own position against.
    n_full, full_m = write_full_path(
        os.path.join(config.OUTPUT_DIR, "full_path_gps.csv"),
        leg_out_raw, spray, flags, leg_home_raw,
        config.PATH_STEP_M, projector.to_lonlat)

    mission = {
        "initial": initial_lonlat,
        "start": projector.to_lonlat(*start_xy),
        "goal": projector.to_lonlat(*goal_xy),
        "leg1_m": leg1_m, "leg2_m": leg2_m, "leg3_m": leg3_m,
    }
    write_specs(
        os.path.join(config.OUTPUT_DIR, "drone_and_spray_specs.txt"),
        spacing, route, total_m, g.polyline_length(spray), n_wp, crossings,
        stats, mission,
    )

    preview = os.path.join(config.OUTPUT_DIR, "path_preview.png")
    save_preview(field_xy, safe_xy, leg_out, spray, flags, leg_home,
                 initial_xy, start_xy, goal_xy, preview, config.SHOW_PLOTS)

    if config.SAVE_ANIMATION:
        print(f"\nRendering the animation ({config.ANIMATION_FRAMES} frames) ...")
        try:
            path_animation.save_path_animation(
                os.path.join(config.OUTPUT_DIR, "path_animation.gif"),
                field_xy, leg_out_raw, spray, flags, leg_home_raw,
                initial_xy, start_xy, goal_xy,
                config.SPRAY_SWATH_WIDTH_M, frames=config.ANIMATION_FRAMES)
        except Exception as exc:          # the animation is optional - never lose the mission files
            print(f"  (animation skipped: {exc})")

    print("\nChosen by the planner:")
    print(f"  START (spray ON)  : {mission['start'][1]:.7f}, {mission['start'][0]:.7f}")
    print(f"  GOAL  (spray OFF) : {mission['goal'][1]:.7f}, {mission['goal'][0]:.7f}")
    print(f"  Leg 1 INITIAL -> START : {leg1_m:8.1f} m")
    print(f"  Leg 2 START -> GOAL    : {leg2_m:8.1f} m")
    print(f"  Leg 3 GOAL -> INITIAL  : {leg3_m:8.1f} m  (straight line)")
    print(f"  Full path              : {n_full} GPS points, one every "
          f"{config.PATH_STEP_M:g} m or less ({full_m:.1f} m in total)")

    print("\nDone. Files written to:", os.path.abspath(config.OUTPUT_DIR))
    for name in ("full_path_gps.csv", "spray_path.kml", "waypoints_gps.txt",
                 "leg1_initial_to_start.csv", "leg2_start_to_goal.csv",
                 "leg3_goal_to_initial.csv",
                 "drone_and_spray_specs.txt", "path_preview.png") + (
            ("path_animation.gif",) if config.SAVE_ANIMATION else ()):
        print(f"  - {name}")
    print(f"\nWaypoints: {n_wp} | Total distance: {total_m:.1f} m")

    display_worked_field(preview)


if __name__ == "__main__":
    main()
