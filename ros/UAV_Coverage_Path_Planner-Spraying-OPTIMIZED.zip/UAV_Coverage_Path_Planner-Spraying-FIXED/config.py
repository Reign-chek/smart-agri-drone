"""
============================================================================
 CONFIGURATION - UAV Spray Coverage Path Planner
============================================================================
Edit the values below for your own field, drone, and mission. Nothing else
in the project normally needs to change.

HOW TO GET YOUR FIELD BOUNDARY FROM GOOGLE EARTH
--------------------------------------------------
 1. Open Google Earth (https://earth.google.com/web or the desktop app).
 2. Fly to your field, click the "Add Polygon" tool, and trace the outline
    of the field by clicking each corner.
 3. Click "Save" and give it a name.
 4. OPTIONAL - drop one pin with the "Add Placemark" tool and NAME it
    exactly:
         INITIAL   where the drone is / takes off and lands
    The program asks you for the drone's position when it runs; a pin
    named INITIAL is offered as the default answer (just press Enter).
    You do NOT mark START or GOAL - the planner chooses the best start
    and goal itself for whatever field you give it.
 5. In "Projects" / "My Places", right-click the project and choose
    "Export as KML File...".
 6. Save it as a .kml and set INPUT_FIELD_KML below to that filename.
============================================================================
"""

# ---------------------------------------------------------------------------
# 1) FIELD BOUNDARY  (exported from Google Earth, see instructions above)
# ---------------------------------------------------------------------------
INPUT_FIELD_KML = "sample_field.kml"

# ---------------------------------------------------------------------------
# 2) SPRAY SWATH
# ---------------------------------------------------------------------------
SPRAY_SWATH_WIDTH_M = 1.5    # effective wetted width of ONE spray pass (= drone width)
SPRAY_OVERLAP_PCT   = 0.0    # 0.15 = 15% overlap between adjacent passes; 0 = lines one full swath apart
                             # (the planner then tightens the gap slightly wherever it must,
                             #  so the lines fit the field exactly - see coverage.build_passes)

# Distance kept between the flight path and the field boundary. The drone
# flies along the centre of its swath, so this is half the swath: the outer
# edge of the spray then lands exactly on the field edge (1.5 m -> 0.75 m).
BOUNDARY_SAFETY_MARGIN_M = SPRAY_SWATH_WIDTH_M / 2

# ---------------------------------------------------------------------------
# 3) PATTERN SHAPE
# ---------------------------------------------------------------------------
# Which way the spray lines RUN.
#   "auto"  - the planner tries every sensible direction, actually plans the
#             whole route for each one, and keeps the cheapest. This is what
#             you want unless you have a reason to override it.
#   "angle" - force the direction yourself with SWEEP_ANGLE_DEG below.
SWEEP_MODE = "auto"

# Only used when SWEEP_MODE = "angle".
#   0  = spray lines run East-West   (drone flies left-right, stepping north)
#   90 = spray lines run North-South (drone flies up-down, stepping east)
# Handy if your crop is planted in rows and you must fly along the rows.
SWEEP_ANGLE_DEG = 0.0

# How much one end-of-row turn "costs" compared to a meter of straight
# flight, when "auto" compares directions. Raise it to bias even harder
# toward long passes and few turns; 0 means judge on flown distance alone.
TURN_PENALTY_M = 10.0

# ---------------------------------------------------------------------------
# 4) TRANSIT LEGS (drone -> field and field -> drone)
# ---------------------------------------------------------------------------
# Applies to LEG 1 only (INITIAL -> START).
# False = fly the straight, shortest line to START (default), even if that
#         means crossing the field. The planner also picks START as the
#         reachable corner of the spray pattern closest to the drone.
# True  = fly AROUND the outside of the field and enter at the nearest edge.
#         Keeps the green transit leg off the crop, but it is longer.
#
# LEG 3 (GOAL -> INITIAL) is not affected by this setting: it is always the
# straight, shortest line home, even if that crosses the field.
TRANSIT_AVOID_FIELD = False

# How far outside the boundary the fly-around route stays (meters).
TRANSIT_CLEARANCE_M = 5.0

# Intermediate GPS waypoints along the transit legs (1 and 3), meters apart.
# Long straight stretches are broken into short hops of at most this length,
# so the drone is given a GPS point to match every few meters and stays on
# the line. Corners of the route are always kept. Set 0 to give only the
# corner points (a straight leg then has just its two end points).
# The spray passes themselves are not affected.
TRANSIT_WAYPOINT_SPACING_M = 10.0

# ---------------------------------------------------------------------------
# 5) INITIAL / START / GOAL  - nothing to set here
#
#    INITIAL = the drone's position (launch & landing). The program ASKS
#              you for it every time it runs, so there is no coordinate to
#              hard-code. (A pin named INITIAL in your KML is offered as the
#              default answer.)
#    START   = where spraying begins.  Chosen by the planner.
#    GOAL    = where spraying ends.    Chosen by the planner.
#
#    START and GOAL are picked from the real corners of the spray pattern:
#    the planner tries every sweep direction and every way of laying the
#    route down, and keeps the one that makes the WHOLE trip shortest -
#    leg 1 (INITIAL -> START) + spraying + leg 3 (GOAL -> INITIAL).
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# 6) OUTPUT
# ---------------------------------------------------------------------------
OUTPUT_DIR = "outputs"

# Step between the GPS points in full_path_gps.csv (meters). That file lists
# the WHOLE trip - INITIAL, out to START, the spray path, GOAL, and back to
# INITIAL - with a coordinate every PATH_STEP_M along it, so the drone always
# has a nearby point to compare its own GPS position against. Corners are
# always kept exactly. Smaller = more points, tighter tracking.
PATH_STEP_M = 1.0
SHOW_PLOTS = False   # True = pop up a matplotlib window while running
SAVE_PLOTS = True    # True = save the preview PNG into OUTPUT_DIR

# Animated GIF of the drone flying the whole mission (path_animation.gif).
# ANIMATION_FRAMES = how many frames the flight is cut into: more = smoother
# and a longer clip (it plays at 20 frames per second) but a bigger file.
SAVE_ANIMATION = True
ANIMATION_FRAMES = 240
