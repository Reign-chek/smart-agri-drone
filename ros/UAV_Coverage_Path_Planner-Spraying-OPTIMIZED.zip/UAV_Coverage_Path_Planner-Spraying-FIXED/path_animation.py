"""
path_animation.py
-----------------
Renders the whole mission as an animated GIF: the drone flies INITIAL -> START
-> the spray path -> GOAL -> INITIAL, leaving a trail behind it that uses the
same colours as the preview image and the KML.

    green  line    transit (pump off)
    blue   line    spraying, with the sprayed ground shaded around it
    orange line    repositioning inside the field (pump off)

The drone is drawn as a triangle pointing the way it is heading, and a short
read-out shows the leg it is on, the distance flown and the pump state.
Frames are spaced evenly by DISTANCE along the path, so the drone moves at a
steady pace on screen.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.collections import LineCollection

import geometry as g

C_BOUNDARY = "#000000"
C_TRANSIT = "#00b050"
C_SPRAY = "#1f5fd0"
C_SPRAYED = "#8fb4ee"
C_REPOSITION = "#ff8000"
C_INITIAL = "#000000"
C_START = "#e00000"
C_GOAL = "#ffd400"
C_DRONE = "#c2185b"

TRANSIT, SPRAY_ON, REPOS = 0, 1, 2
LEG_NAMES = {0: "Leg 1: INITIAL -> START", 1: "Leg 2: SPRAYING", 2: "Leg 2: SPRAYING",
             3: "Leg 3: GOAL -> INITIAL"}


def _build_track(leg_out, spray, flags, leg_home):
    """One list of corner points for the whole trip, with, per segment, its
    kind (transit / spraying / repositioning) and which leg it belongs to."""
    pts = list(leg_out)
    kind = [TRANSIT] * (len(leg_out) - 1)
    leg = [0] * (len(leg_out) - 1)
    for i in range(1, len(spray)):
        pts.append(spray[i])
        kind.append(SPRAY_ON if flags[i] else REPOS)
        leg.append(1 if flags[i] else 2)
    for p in leg_home[1:]:
        pts.append(p)
        kind.append(TRANSIT)
        leg.append(3)
    return np.asarray(pts, dtype=float), np.asarray(kind), np.asarray(leg)


def save_path_animation(out_path, field_xy, leg_out, spray, flags, leg_home,
                        initial_xy, start_xy, goal_xy, swath_m,
                        frames=240, fps=20):
    pts, kind, leg = _build_track(leg_out, spray, flags, leg_home)
    seg_len = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    cum = np.concatenate([[0.0], np.cumsum(seg_len)])
    total = float(cum[-1])
    if total <= 0 or len(pts) < 2:
        return 0

    # ---- figure, fixed view over the field and the drone's position ------
    fig, ax = plt.subplots(figsize=(8, 6.6), dpi=80)
    allx = [p[0] for p in field_xy] + [initial_xy[0]]
    ally = [p[1] for p in field_xy] + [initial_xy[1]]
    pad = 0.06 * max(max(allx) - min(allx), max(ally) - min(ally), 1.0)
    ax.set_xlim(min(allx) - pad, max(allx) + pad)
    ax.set_ylim(min(ally) - pad, max(ally) + pad)
    ax.set_aspect("equal")
    ax.set_xlabel("meters (east)")
    ax.set_ylabel("meters (north)")
    ax.set_title("UAV Spray Path", fontsize=12, fontweight="bold")
    ax.grid(True, alpha=0.25)

    fx, fy = zip(*g.close_ring(field_xy))
    ax.plot(fx, fy, color=C_BOUNDARY, lw=2.2, zorder=6)
    ax.scatter(*initial_xy, s=110, marker="s", facecolors="white",
               edgecolors=C_INITIAL, linewidths=2, zorder=9)
    ax.scatter(*start_xy, s=110, marker="o", c=C_START, edgecolors="black",
               linewidths=1.2, zorder=10)
    ax.scatter(*goal_xy, s=110, marker="o", c=C_GOAL, edgecolors="black",
               linewidths=1.2, zorder=10)
    for xy, txt, col in ((initial_xy, "INITIAL", C_INITIAL),
                         (start_xy, "START", C_START),
                         (goal_xy, "GOAL", "#9a7d00")):
        ax.annotate(txt, xy=xy, xytext=(8, 8), textcoords="offset points",
                    fontsize=8, fontweight="bold", color=col, zorder=11,
                    bbox=dict(boxstyle="round,pad=0.2", fc="white", ec=col, lw=1, alpha=0.9))

    fig.tight_layout()
    fig.canvas.draw()
    # metres -> points, so the shaded band is the real swath width on screen
    p0 = ax.transData.transform((0.0, 0.0))
    p1 = ax.transData.transform((1.0, 0.0))
    pts_per_m = float(p1[0] - p0[0]) * 72.0 / fig.dpi
    swath_lw = max(swath_m * pts_per_m, 1.0)

    # ---- artists that grow as the drone flies ----------------------------
    segs = np.stack([pts[:-1], pts[1:]], axis=1)          # (n_seg, 2, 2)
    band = LineCollection([], colors=C_SPRAYED, linewidths=swath_lw,
                          capstyle="round", zorder=2, alpha=0.7)
    ax.add_collection(band)
    lines = {}
    for k, (col, lw, z) in {TRANSIT: (C_TRANSIT, 2.2, 5), SPRAY_ON: (C_SPRAY, 1.0, 4),
                            REPOS: (C_REPOSITION, 1.2, 4)}.items():
        lines[k] = LineCollection([], colors=col, linewidths=lw, zorder=z)
        ax.add_collection(lines[k])
    drone, = ax.plot([], [], marker=(3, 0, 0), ms=13, color=C_DRONE,
                     mec="black", mew=0.8, ls="none", zorder=12)
    hud = ax.text(0.01, 0.99, "", transform=ax.transAxes, va="top", ha="left",
                  fontsize=9, family="monospace", zorder=13,
                  bbox=dict(boxstyle="round,pad=0.35", fc="white", ec="#888888", alpha=0.92))

    from matplotlib.lines import Line2D
    ax.legend(handles=[
        Line2D([0], [0], color=C_TRANSIT, lw=2.2, label="Transit (pump off)"),
        Line2D([0], [0], color=C_SPRAY, lw=1.2, label="Spraying"),
        Line2D([0], [0], color=C_SPRAYED, lw=6, label="Sprayed ground"),
        Line2D([0], [0], color=C_REPOSITION, lw=1.4, label="Repositioning (pump off)"),
    ], loc="lower right", fontsize=7.5, framealpha=0.92)

    # ---- frame schedule: even by distance, with a pause at each end -------
    hold_start, hold_end = fps // 2, fps
    dists = np.concatenate([np.zeros(hold_start),
                            np.linspace(0.0, total, max(2, frames)),
                            np.full(hold_end, total)])

    def draw(d):
        i = int(np.searchsorted(cum, d, side="right")) - 1
        i = min(max(i, 0), len(segs) - 1)
        t = 0.0 if seg_len[i] <= 0 else (d - cum[i]) / seg_len[i]
        t = min(max(t, 0.0), 1.0)
        pos = pts[i] + t * (pts[i + 1] - pts[i])
        partial = np.stack([pts[i], pos])[None]
        done = kind[:i]
        for k, coll in lines.items():
            s = segs[:i][done == k]
            if kind[i] == k:
                s = np.concatenate([s, partial]) if len(s) else partial
            coll.set_segments(s)
        s_on = segs[:i][done == SPRAY_ON]
        if kind[i] == SPRAY_ON:
            s_on = np.concatenate([s_on, partial]) if len(s_on) else partial
        band.set_segments(s_on)

        dx, dy = pts[i + 1] - pts[i]
        if dx or dy:
            heading = np.degrees(np.arctan2(dy, dx))
            drone.set_marker((3, 0, heading - 90.0))
        drone.set_data([pos[0]], [pos[1]])
        pump = "ON " if kind[i] == SPRAY_ON else "OFF"
        finished = d >= total - 1e-9
        hud.set_text(("Mission complete\n" if finished else LEG_NAMES[int(leg[i])] + "\n")
                     + f"Distance: {d:,.0f} / {total:,.0f} m\nPump: {pump}")
        return []

    anim = FuncAnimation(fig, lambda f: draw(dists[f]), frames=len(dists), blit=False)
    anim.save(out_path, writer=PillowWriter(fps=fps))
    plt.close(fig)
    return len(dists)
