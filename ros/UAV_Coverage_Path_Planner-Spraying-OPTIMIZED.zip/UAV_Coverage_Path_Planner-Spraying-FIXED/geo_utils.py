"""
geo_utils.py
------------
Small helper for converting between GPS coordinates (WGS84 lat/lon, the
format Google Earth and the drone's GPS module both use) and a local, flat
metric (meters) coordinate system centered on the field.

Doing the actual geometry (spacing, offsets, distances) in meters instead of
raw degrees is important for a sprayer: 1 degree of longitude is NOT the
same physical distance as 1 degree of latitude (longitude distance shrinks
as you move away from the equator), so mixing them directly would distort
line spacing and make the spray swath width inaccurate. All internal
planning happens in meters; coordinates are only converted back to
lat/lon at the very end, right before writing the KML / waypoint files.
"""

from math import radians, cos


class LocalProjector:
    """Equirectangular local projection centered at (lat0, lon0).

    Accurate to well under 1% for field-sized areas (tens of meters up to a
    few kilometers across), which is more than sufficient for path spacing
    driven by a spray swath width of a few meters.
    """

    def __init__(self, lat0, lon0):
        self.lat0 = lat0
        self.lon0 = lon0
        # Meters-per-degree at this latitude (standard WGS84 approximation).
        self.m_per_deg_lat = (
            111132.92
            - 559.82 * cos(radians(2 * lat0))
            + 1.175 * cos(radians(4 * lat0))
        )
        self.m_per_deg_lon = 111412.84 * cos(radians(lat0)) - 93.5 * cos(
            radians(3 * lat0)
        )

    def to_xy(self, lon, lat):
        """lon/lat (degrees) -> (x, y) meters, relative to the projection center."""
        x = (lon - self.lon0) * self.m_per_deg_lon
        y = (lat - self.lat0) * self.m_per_deg_lat
        return (x, y)

    def to_lonlat(self, x, y):
        """(x, y) meters -> (lon, lat) degrees."""
        lon = self.lon0 + x / self.m_per_deg_lon
        lat = self.lat0 + y / self.m_per_deg_lat
        return (lon, lat)

    @classmethod
    def from_polygon(cls, lonlat_points):
        """Build a projector centered on the centroid of a list of (lon, lat) points."""
        lons = [p[0] for p in lonlat_points]
        lats = [p[1] for p in lonlat_points]
        lon0 = sum(lons) / len(lons)
        lat0 = sum(lats) / len(lats)
        return cls(lat0, lon0)
