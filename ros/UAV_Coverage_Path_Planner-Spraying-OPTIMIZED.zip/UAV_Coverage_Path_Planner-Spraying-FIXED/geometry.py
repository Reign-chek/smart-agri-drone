"""
geometry.py
-----------
Small, dependency-light planar geometry toolkit used by the spray planner.

Everything in here works on simple polygons given as a list of (x, y) points
in METERS (the local flat frame produced by geo_utils.LocalProjector). Points
are plain tuples; polygons are plain lists of points WITHOUT a repeated
closing point.

Why hand-rolled instead of shapely?
  * the planner only needs a handful of operations (inset/outset, clipping a
    line to a polygon, "is this segment inside", shortest path inside a
    polygon), and
  * keeping them here means the whole project installs with just numpy +
    matplotlib, and every step is transparent/tweakable.
"""

from heapq import heappush, heappop
from math import atan2, cos, hypot, sin

import numpy as np

EPS = 1e-9


# ---------------------------------------------------------------------------
# basic vector helpers
# ---------------------------------------------------------------------------
def sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def scale(a, s):
    return (a[0] * s, a[1] * s)


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def cross(a, b):
    return a[0] * b[1] - a[1] * b[0]


def norm(a):
    return hypot(a[0], a[1])


def dist(a, b):
    return hypot(a[0] - b[0], a[1] - b[1])


def unit(a):
    n = norm(a)
    return (a[0] / n, a[1] / n) if n > EPS else (0.0, 0.0)


# ---------------------------------------------------------------------------
# polygon basics
# ---------------------------------------------------------------------------
def close_ring(poly):
    """Return the polygon with its first point repeated at the end."""
    return list(poly) + [poly[0]]


def strip_ring(poly):
    """Drop a repeated closing point if present."""
    pts = list(poly)
    while len(pts) > 1 and dist(pts[0], pts[-1]) < 1e-9:
        pts.pop()
    return pts


def signed_area(poly):
    pts = strip_ring(poly)
    s = 0.0
    for i in range(len(pts)):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % len(pts)]
        s += x1 * y2 - x2 * y1
    return s / 2.0


def area(poly):
    return abs(signed_area(poly))


def ensure_ccw(poly):
    pts = strip_ring(poly)
    return pts if signed_area(pts) > 0 else pts[::-1]


def centroid(poly):
    pts = strip_ring(poly)
    a = signed_area(pts)
    if abs(a) < EPS:
        return (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))
    cx = cy = 0.0
    for i in range(len(pts)):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % len(pts)]
        f = x1 * y2 - x2 * y1
        cx += (x1 + x2) * f
        cy += (y1 + y2) * f
    return (cx / (6 * a), cy / (6 * a))


def bounds(poly):
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    return (min(xs), min(ys), max(xs), max(ys))


def point_in_polygon(pt, poly):
    """Ray-casting test. Points exactly on the edge may return either value."""
    x, y = pt
    pts = strip_ring(poly)
    inside = False
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            xint = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
            if x < xint:
                inside = not inside
    return inside


def point_to_segment_distance(p, a, b):
    ab = sub(b, a)
    L2 = dot(ab, ab)
    if L2 < EPS:
        return dist(p, a)
    t = max(0.0, min(1.0, dot(sub(p, a), ab) / L2))
    proj = add(a, scale(ab, t))
    return dist(p, proj)


def nearest_point_on_boundary(p, poly):
    """Closest point on the polygon's boundary (not interior) to p."""
    pts = strip_ring(poly)
    best, best_d = pts[0], float("inf")
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        ab = sub(b, a)
        L2 = dot(ab, ab)
        t = 0.0 if L2 < EPS else max(0.0, min(1.0, dot(sub(p, a), ab) / L2))
        q = add(a, scale(ab, t))
        d = dist(p, q)
        if d < best_d:
            best, best_d = q, d
    return best


def distance_to_boundary(p, poly):
    return dist(p, nearest_point_on_boundary(p, poly))


def perimeter(poly):
    pts = strip_ring(poly)
    return sum(dist(pts[i], pts[(i + 1) % len(pts)]) for i in range(len(pts)))


def convex_hull(points):
    """Andrew's monotone chain. Returns hull in CCW order."""
    pts = sorted(set((round(p[0], 9), round(p[1], 9)) for p in points))
    if len(pts) <= 2:
        return pts

    def build(seq):
        out = []
        for p in seq:
            while len(out) >= 2 and cross(sub(out[-1], out[-2]), sub(p, out[-2])) <= 0:
                out.pop()
            out.append(p)
        return out

    lower = build(pts)
    upper = build(reversed(pts))
    return lower[:-1] + upper[:-1]


# ---------------------------------------------------------------------------
# simplification (Douglas-Peucker)
# ---------------------------------------------------------------------------
def simplify_polyline(points, tol):
    if len(points) < 3 or tol <= 0:
        return list(points)
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        a, b = points[i], points[j]
        worst, worst_d = -1, 0.0
        for k in range(i + 1, j):
            d = point_to_segment_distance(points[k], a, b)
            if d > worst_d:
                worst, worst_d = k, d
        if worst_d > tol and worst > 0:
            keep[worst] = True
            stack.append((i, worst))
            stack.append((worst, j))
    return [p for p, k in zip(points, keep) if k]


def simplify_polygon(poly, tol):
    """Simplify a closed ring, keeping it closed and valid."""
    pts = strip_ring(poly)
    if len(pts) < 4:
        return pts
    simplified = simplify_polyline(pts + [pts[0]], tol)
    simplified = strip_ring(simplified)
    if len(simplified) < 3 or area(simplified) < area(pts) * 0.5:
        return pts
    return simplified


# ---------------------------------------------------------------------------
# self-intersection check
# ---------------------------------------------------------------------------
def _side(a, b, p, tol):
    """Which side of line a-b the point p is on: -1, 0 (on the line) or +1.

    Uses a real perpendicular DISTANCE with a tolerance, not a raw cross
    product. Two spray passes that both end on the same field edge are
    collinear in intent but differ by ~1e-14 m after projection; a raw cross
    product reports that as a genuine crossing and the mission gets flagged
    as self-intersecting when it is perfectly clean.
    """
    ab = sub(b, a)
    L = norm(ab)
    if L < EPS:
        return 0
    d = cross(ab, sub(p, a)) / L
    if abs(d) <= tol:
        return 0
    return 1 if d > 0 else -1


def _segments_properly_intersect(p1, p2, p3, p4, tol=1e-6):
    d1 = _side(p1, p2, p3, tol)
    d2 = _side(p1, p2, p4, tol)
    d3 = _side(p3, p4, p1, tol)
    d4 = _side(p3, p4, p2, tol)
    return d1 * d2 < 0 and d3 * d4 < 0


def is_simple_polygon(poly):
    pts = strip_ring(poly)
    n = len(pts)
    if n < 3:
        return False
    for i in range(n):
        a1, a2 = pts[i], pts[(i + 1) % n]
        for j in range(i + 1, n):
            if j == i or (j + 1) % n == i or (i + 1) % n == j:
                continue
            b1, b2 = pts[j], pts[(j + 1) % n]
            if _segments_properly_intersect(a1, a2, b1, b2):
                return False
    return True


# ---------------------------------------------------------------------------
# polygon offsetting (inset / outset)
# ---------------------------------------------------------------------------
def _miter_offset(poly_ccw, d):
    """Offset every edge by d to the LEFT of its direction (= inward for a
    CCW ring when d > 0) and re-intersect neighbouring edges."""
    pts = strip_ring(poly_ccw)
    n = len(pts)
    lines = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        e = unit(sub(b, a))
        if e == (0.0, 0.0):
            continue
        nrm = (-e[1], e[0])  # left normal
        lines.append((add(a, scale(nrm, d)), e))
    if len(lines) < 3:
        return []

    out = []
    m = len(lines)
    for i in range(m):
        p1, e1 = lines[i - 1]
        p2, e2 = lines[i]
        denom = cross(e1, e2)
        if abs(denom) < 1e-12:
            out.append(p2)  # near-parallel: just use the offset endpoint
            continue
        t = cross(sub(p2, p1), e2) / denom
        out.append(add(p1, scale(e1, t)))
    return out


def _offset_by_raster(poly, d, inward=True):
    """Robust fall-back: build a distance field on a grid and trace the
    iso-contour at distance d. Handles nasty concave shapes where a plain
    miter offset would fold over itself."""
    from matplotlib.path import Path
    import matplotlib.pyplot as plt
    from scipy.ndimage import distance_transform_edt

    pts = strip_ring(poly)
    minx, miny, maxx, maxy = bounds(pts)
    pad = d * 2 + 1.0
    minx, miny, maxx, maxy = minx - pad, miny - pad, maxx + pad, maxy + pad

    h = max(min(0.25, d / 6.0), max(maxx - minx, maxy - miny) / 1800.0)
    nx = max(16, int((maxx - minx) / h) + 1)
    ny = max(16, int((maxy - miny) / h) + 1)
    xs = np.linspace(minx, maxx, nx)
    ys = np.linspace(miny, maxy, ny)
    gx, gy = np.meshgrid(xs, ys)

    path = Path(np.array(close_ring(pts)))
    inside = path.contains_points(
        np.column_stack([gx.ravel(), gy.ravel()])
    ).reshape(gx.shape)

    mask = inside if inward else ~inside
    hx = (maxx - minx) / (nx - 1)
    hy = (maxy - miny) / (ny - 1)
    dist_field = distance_transform_edt(mask, sampling=(hy, hx))

    fig = plt.figure()
    try:
        cs = plt.contour(gx, gy, dist_field, levels=[d])
        segs = cs.allsegs[0]
    finally:
        plt.close(fig)

    rings = [strip_ring([(float(p[0]), float(p[1])) for p in s]) for s in segs if len(s) >= 4]
    rings = [r for r in rings if len(r) >= 3]
    if not rings:
        return []
    ring = max(rings, key=area)
    return simplify_polygon(ensure_ccw(ring), max(hx, hy) * 1.5)


def inset_polygon(poly, d):
    """Shrink a polygon inward by d meters (the drone safety margin)."""
    if d <= 0:
        return ensure_ccw(poly)
    base = ensure_ccw(simplify_polygon(poly, 0.05))
    cand = _miter_offset(base, d)

    ok = bool(cand) and len(cand) >= 3 and is_simple_polygon(cand)
    if ok:
        ok = signed_area(cand) > 0 and area(cand) < area(base)
        if ok:
            for p in cand:
                if not point_in_polygon(p, base) or distance_to_boundary(p, base) < d * 0.85:
                    ok = False
                    break
    if ok:
        return ensure_ccw(cand)

    fallback = _offset_by_raster(base, d, inward=True)
    if not fallback:
        raise ValueError(
            "The boundary safety margin is too large for this field - it shrinks "
            "to nothing. Reduce the drone dimensions / safety margin in config.py."
        )
    return ensure_ccw(fallback)


def outset_polygon(poly, d):
    """Grow a polygon outward by d meters (used for the fly-around transit ring)."""
    if d <= 0:
        return ensure_ccw(poly)
    base = ensure_ccw(simplify_polygon(poly, 0.05))
    cand = _miter_offset(base, -d)

    ok = bool(cand) and len(cand) >= 3 and is_simple_polygon(cand)
    if ok:
        ok = signed_area(cand) > 0 and area(cand) > area(base)
        if ok:
            for p in cand:
                if point_in_polygon(p, base):
                    ok = False
                    break
    if ok:
        return ensure_ccw(cand)

    fallback = _offset_by_raster(base, d, inward=False)
    return ensure_ccw(fallback) if fallback else ensure_ccw(base)


# ---------------------------------------------------------------------------
# clipping a line / segment against a polygon
# ---------------------------------------------------------------------------
def clip_line_to_polygon(poly, origin, direction):
    """Intersect the INFINITE line (origin + t*direction) with a simple
    polygon. Returns a list of (t_in, t_out) intervals that lie inside,
    sorted along t."""
    u = unit(direction)
    v = (-u[1], u[0])
    pts = strip_ring(poly)
    n = len(pts)

    ts = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        da = dot(sub(a, origin), v)
        db = dot(sub(b, origin), v)
        if (da > 0) == (db > 0):
            continue  # both on the same side -> no crossing
        s = da / (da - db)
        x = a[0] + s * (b[0] - a[0])
        y = a[1] + s * (b[1] - a[1])
        ts.append(dot(sub((x, y), origin), u))

    ts.sort()
    intervals = []
    for i in range(0, len(ts) - 1, 2):
        t0, t1 = ts[i], ts[i + 1]
        if t1 - t0 <= 1e-7:
            continue
        mid = add(origin, scale(u, (t0 + t1) / 2))
        if point_in_polygon(mid, pts):
            intervals.append((t0, t1))
    return intervals


def collinear_overlap_length(a, b, poly, tol=1e-6):
    """How much of segment a-b runs exactly ALONG an edge of the polygon.

    Spray passes end on the field boundary, so the short turn joining two
    passes often runs straight down the boundary edge. That is perfectly
    legal flying, but a pure inside/outside test reports it as "not inside"
    (it is on the line, not strictly within), which used to make the planner
    insert a pointless detour. Measuring it explicitly avoids that.
    """
    L = dist(a, b)
    if L < tol:
        return 0.0
    u = unit(sub(b, a))
    pts = strip_ring(poly)
    covered = []
    for i in range(len(pts)):
        p, q = pts[i], pts[(i + 1) % len(pts)]
        e = sub(q, p)
        if norm(e) < tol:
            continue
        eu = unit(e)
        if abs(cross(u, eu)) > 1e-7:
            continue  # not parallel
        if abs(cross(u, sub(p, a))) > 1e-4:
            continue  # parallel but offset from our segment
        t_p, t_q = dot(sub(p, a), u), dot(sub(q, a), u)
        lo, hi = max(min(t_p, t_q), 0.0), min(max(t_p, t_q), L)
        if hi > lo:
            covered.append((lo, hi))

    covered.sort()
    total, cur_hi = 0.0, None
    for lo, hi in covered:
        if cur_hi is None or lo > cur_hi:
            total += hi - lo
            cur_hi = hi
        elif hi > cur_hi:
            total += hi - cur_hi
            cur_hi = hi
    return total


def segment_inside_polygon(a, b, poly, tol=1e-6):
    """True if the whole segment a-b lies inside the polygon or along its edge."""
    L = dist(a, b)
    if L < tol:
        return point_in_polygon(a, poly) or distance_to_boundary(a, poly) < 1e-3
    u = unit(sub(b, a))
    inside_len = 0.0
    for t0, t1 in clip_line_to_polygon(poly, a, u):
        lo, hi = max(t0, 0.0), min(t1, L)
        if hi > lo:
            inside_len += hi - lo
    if inside_len >= L - max(tol, L * 1e-6):
        return True
    inside_len += collinear_overlap_length(a, b, poly, tol)
    return inside_len >= L - max(1e-4, L * 1e-5)


def segment_outside_polygon(a, b, poly, tol=1e-6):
    """True if the segment a-b never enters the polygon's interior."""
    L = dist(a, b)
    if L < tol:
        return not point_in_polygon(a, poly)
    u = unit(sub(b, a))
    inside_len = 0.0
    for t0, t1 in clip_line_to_polygon(poly, a, u):
        lo, hi = max(t0, 0.0), min(t1, L)
        if hi > lo:
            inside_len += hi - lo
    return inside_len <= max(tol, L * 1e-6)


# ---------------------------------------------------------------------------
# shortest obstacle-free path INSIDE a polygon (visibility graph + Dijkstra)
# ---------------------------------------------------------------------------
def shortest_path_inside(a, b, poly, shrink=0.02):
    """Shortest route from a to b that never leaves `poly`. Returns a list of
    points starting at a and ending at b. Falls back to a straight line if no
    route is found (should not happen for a connected field)."""
    if segment_inside_polygon(a, b, poly):
        return [a, b]

    pts = strip_ring(simplify_polygon(poly, 0.2))
    pts = pts if signed_area(pts) > 0 else pts[::-1]   # CCW, so a "left of
                                                        # the edge" normal is
                                                        # guaranteed inward
    # pull the corner nodes very slightly inward so they count as "inside"
    c = centroid(pts)
    m = len(pts)
    nodes = [a, b]
    for i, p in enumerate(pts):
        # Nudge each corner toward the polygon's own interior, not toward
        # the centroid: on a concave (reflex) corner - the inner wall of an
        # L or U shape - the centroid can sit on the FAR side of the notch,
        # so "toward the centroid" pushes the node outside the field and
        # the visibility graph silently loses that corner, forcing the
        # route the long way around instead of across. The interior angle
        # bisector (average of the two inward edge normals) always points
        # into the field, at a convex corner as well as a reflex one.
        prev_p, next_p = pts[i - 1], pts[(i + 1) % m]
        e_in = unit(sub(p, prev_p))
        e_out = unit(sub(next_p, p))
        n_in = (-e_in[1], e_in[0])
        n_out = (-e_out[1], e_out[0])
        bis = (n_in[0] + n_out[0], n_in[1] + n_out[1])
        bis = unit(bis) if norm(bis) > EPS else n_in
        mag = shrink * 0.05 * dist(p, c)
        nodes.append((p[0] + bis[0] * mag, p[1] + bis[1] * mag))

    n = len(nodes)
    adj = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if segment_inside_polygon(nodes[i], nodes[j], poly, tol=1e-3):
                w = dist(nodes[i], nodes[j])
                adj[i].append((j, w))
                adj[j].append((i, w))

    dist_to = [float("inf")] * n
    prev = [-1] * n
    dist_to[0] = 0.0
    pq = [(0.0, 0)]
    while pq:
        d0, i = heappop(pq)
        if d0 > dist_to[i] + EPS:
            continue
        if i == 1:
            break
        for j, w in adj[i]:
            nd = d0 + w
            if nd < dist_to[j] - EPS:
                dist_to[j] = nd
                prev[j] = i
                heappush(pq, (nd, j))

    if dist_to[1] == float("inf"):
        return [a, b]

    path, cur = [], 1
    while cur != -1:
        path.append(nodes[cur])
        cur = prev[cur]
    return path[::-1]


# ---------------------------------------------------------------------------
# walking around the outside of a ring (used for transit legs)
# ---------------------------------------------------------------------------
def _ring_positions(poly):
    pts = strip_ring(poly)
    cum = [0.0]
    for i in range(len(pts)):
        cum.append(cum[-1] + dist(pts[i], pts[(i + 1) % len(pts)]))
    return pts, cum


def project_onto_ring(p, poly):
    """Return (point, arc-length position) of the closest point on the ring."""
    pts, cum = _ring_positions(poly)
    best = (pts[0], 0.0, float("inf"))
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        ab = sub(b, a)
        L2 = dot(ab, ab)
        t = 0.0 if L2 < EPS else max(0.0, min(1.0, dot(sub(p, a), ab) / L2))
        q = add(a, scale(ab, t))
        d = dist(p, q)
        if d < best[2]:
            best = (q, cum[i] + t * dist(a, b), d)
    return best[0], best[1]


def walk_ring(poly, s0, s1):
    """Corner points along the ring between arc-length positions s0 and s1,
    taking whichever way round is shorter. Endpoints are NOT included."""
    pts, cum = _ring_positions(poly)
    total = cum[-1]
    if total < EPS:
        return []

    verts = [(cum[i] % total, pts[i]) for i in range(len(pts))]
    fwd = (s1 - s0) % total
    bwd = total - fwd

    if fwd <= bwd:
        picked = [(((pos - s0) % total), p) for pos, p in verts]
        picked = [(o, p) for o, p in picked if 1e-6 < o < fwd - 1e-6]
        picked.sort(key=lambda kp: kp[0])
    else:
        picked = [(((s0 - pos) % total), p) for pos, p in verts]
        picked = [(o, p) for o, p in picked if 1e-6 < o < bwd - 1e-6]
        picked.sort(key=lambda kp: kp[0])
    return [p for _, p in picked]


# ---------------------------------------------------------------------------
# path helpers
# ---------------------------------------------------------------------------
def polyline_length(points):
    return sum(dist(points[i], points[i + 1]) for i in range(len(points) - 1))


def dedupe_consecutive(points, tol=1e-6):
    out = []
    for p in points:
        if not out or dist(out[-1], p) > tol:
            out.append(p)
    return out


def count_self_crossings(points, ignore_adjacent=True):
    """Number of places where a polyline crosses itself - used as a quality
    check on the generated mission (we want this at or near zero)."""
    pts = dedupe_consecutive(points)
    n = len(pts) - 1
    crossings = 0
    for i in range(n):
        a1, a2 = pts[i], pts[i + 1]
        for j in range(i + 2, n):
            if ignore_adjacent and j == i + 1:
                continue
            b1, b2 = pts[j], pts[j + 1]
            if _segments_properly_intersect(a1, a2, b1, b2):
                crossings += 1
    return crossings


def rotate(p, angle):
    ca, sa = cos(angle), sin(angle)
    return (p[0] * ca - p[1] * sa, p[0] * sa + p[1] * ca)


def angle_of(a, b):
    return atan2(b[1] - a[1], b[0] - a[0])
