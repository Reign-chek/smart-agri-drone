"""
coverage.py
-----------
Builds the actual spray pattern.

WHAT CHANGED vs. the old planner (and why the path used to cross itself)
------------------------------------------------------------------------
The previous version cut the field into convex cells and ran a separate
lawnmower inside EACH cell. Every cell picked its own line direction (its
own longest edge), and the cells were then stitched together with a grid
A* route that was free to run diagonally straight back across ground that
had already been sprayed. That is what produced the long diagonal streak
cutting through the middle of the pattern and the tangled knot of crossing
lines.

This version does the opposite:

  1. ONE sweep direction for the whole field, chosen once so the number of
     passes (and therefore the number of turns) is as low as possible.
  2. Parallel sweep lines across the entire field at the spray spacing.
     Each line is clipped to the field, so a concave field simply yields
     several shorter segments on that line instead of one long one.
  3. Segments are grouped into "bands" - sets of segments that are
     reachable from one line to the next without leaving the field. Inside
     a band the passes are flown strictly in order, alternating direction,
     so consecutive passes are joined by a short turn at the edge and the
     path physically CANNOT cross itself.
  4. Where two bands must be joined (only happens on genuinely awkward
     shapes), they're joined by the shortest route that stays inside the
     field, computed on a visibility graph, rather than a straight diagonal
     over the crop.

Because passes are laid down once, no ground is ever sprayed twice and there
is no gap between passes. The spacing is never wider than one swath: it is
fitted to the field (see build_passes) so the outermost lines sit exactly half
a swath from the field edge, and so does a line on every interior wall that
runs parallel to the lines (the inner wall of an L, the arms of a U, ...).

START and GOAL are NOT inputs. They are the two ends of the finished route,
and the planner picks the arrangement (sweep direction, which end to enter,
which cell to begin in, forwards or backwards) that makes the whole mission -
leg 1 + spraying + straight leg 3 home - shortest. See build_coverage_route.
"""

from math import atan2, ceil, cos, degrees, pi, radians, sin

import geometry as g


class Pass:
    """One straight spray line (or one piece of it, on a concave field)."""

    __slots__ = ("k", "a", "b", "u0", "u1", "c")

    def __init__(self, k, a, b, u0, u1, c=0.0):
        self.k = k      # which sweep line it belongs to (0 = first)
        self.a = a      # endpoint at the LOW end of the along-line axis
        self.b = b      # endpoint at the HIGH end
        self.u0 = u0
        self.u1 = u1
        self.c = c      # sideways position of the line (metres along the normal)

    @property
    def length(self):
        return g.dist(self.a, self.b)


# ---------------------------------------------------------------------------
# 1) pick the sweep direction
# ---------------------------------------------------------------------------
def choose_sweep_angle(poly, mode="auto", fixed_angle_deg=0.0):
    """Direction the spray lines RUN ALONG, in radians.

    mode="auto"  : the direction that needs the fewest passes. Fewest passes
                   means fewest end-of-row turns, which is what actually
                   costs a sprayer time and battery.
    mode="angle" : use fixed_angle_deg exactly (0 = lines run East-West,
                   90 = lines run North-South).
    """
    if mode == "angle":
        return radians(fixed_angle_deg)

    hull = g.convex_hull(g.strip_ring(poly))
    if len(hull) < 3:
        return 0.0

    best_angle, best_width = 0.0, float("inf")
    for i in range(len(hull)):
        a, b = hull[i], hull[(i + 1) % len(hull)]
        edge = g.unit(g.sub(b, a))
        if edge == (0.0, 0.0):
            continue
        ang = atan2(edge[1], edge[0])
        v = (-edge[1], edge[0])
        projs = [g.dot(p, v) for p in hull]
        width = max(projs) - min(projs)
        if width < best_width - 1e-9:
            best_width, best_angle = width, ang
    return best_angle


# ---------------------------------------------------------------------------
# 2) lay down the parallel passes
# ---------------------------------------------------------------------------
# An edge of the safe boundary counts as a WALL (parallel to the spray lines)
# if it is at least WALL_MIN_LEN_M long and drifts sideways by no more than
# half a spacing over its whole length (a single line on the field side of
# such an edge is then never more than half a swath from any point of it).
# Levels closer together than LEVEL_MERGE_M are treated as the same level.
# A line that must sit ON the boundary is placed FLUSH_INSET_M inside it, so
# floating-point noise can never push it just outside and lose the pass.
WALL_MIN_LEN_M = 1.0
LEVEL_MERGE_M = 0.05
FLUSH_INSET_M = 0.001


def _line_levels(poly, v, lo, hi, wall_tol):
    """Sideways positions where a spray line MUST run, as [(level, nudge)].

    A line has to sit exactly on the safe boundary (half a swath from the real
    field edge) wherever that boundary runs parallel to the lines - otherwise
    a strip along that edge is never sprayed. That is the two extreme levels
    (`lo`, `hi`) AND every interior wall: e.g. the inner wall of an L-shaped
    field, or the two inner walls of a U. For a wall that is not perfectly
    parallel the line goes at the end of the wall that lies on the field side,
    so it stays inside the field along the whole wall.

    `nudge` (+1 / -1) is the direction to step a line by a centimetre if it
    lands exactly on the boundary and would otherwise be clipped away.
    """
    pts = g.strip_ring(poly)
    n = len(pts)
    ccw = g.signed_area(pts) > 0
    walls = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        e = g.sub(b, a)
        if g.norm(e) < WALL_MIN_LEN_M:
            continue
        ca, cb = g.dot(a, v), g.dot(b, v)
        if abs(ca - cb) > wall_tol:
            continue
        side = g.dot((-e[1], e[0]), v)          # left of the edge = inside (CCW)
        if not ccw:
            side = -side
        walls.append((max(ca, cb), +1) if side > 0 else (min(ca, cb), -1))

    walls.sort()
    inner = []
    for c, d in walls:
        if c - lo < LEVEL_MERGE_M or hi - c < LEVEL_MERGE_M:
            continue                              # same as an extreme level
        if inner and c - inner[-1][0] < LEVEL_MERGE_M:
            continue
        inner.append((c, d))
    return [(lo, +1)] + inner + [(hi, -1)]


def build_passes(poly, spacing, angle, min_pass_length=0.5):
    """Lay the parallel spray lines across the field.

    `spacing` is the NOMINAL gap between lines (the drone's swath width when
    there is no overlap). Lines are never placed further apart than that; the
    real gap is adjusted so the lines fit the field exactly:

      * the outermost lines sit flush on the safe boundary (half a swath from
        the field edge), and so does a line on every interior wall parallel to
        the lines;
      * between two such fixed levels, the gap G is divided into
            n = ceil(G / spacing)
        equal steps of G / n  (<= spacing), so consecutive lines are never
        more than one swath apart and no strip is left unsprayed.

    Each band of the field (each arm of an L or U, for instance) is therefore
    fitted on its own, instead of one grid being stretched over the whole
    field and landing wherever it lands relative to the inner walls.
    """
    u = (cos(angle), sin(angle))
    v = (-u[1], u[0])

    projs = [g.dot(p, v) for p in g.strip_ring(poly)]
    lo, hi = min(projs), max(projs)
    span = hi - lo
    if span <= 1e-6:
        return [], u, v

    levels = _line_levels(poly, v, lo, hi, spacing / 2.0)
    line_levels = []                              # (sideways position, nudge)
    for (c0, d0), (c1, d1) in zip(levels, levels[1:]):
        gap = c1 - c0
        n = max(1, int(ceil(gap / spacing - 1e-9)))
        step = gap / n
        for j in range(n):
            line_levels.append((c0 + j * step, d0 if j == 0 else 0))
    line_levels.append((hi, -1))

    def clip(c):
        origin = g.scale(v, c)
        kept = [(t0, t1) for t0, t1 in g.clip_line_to_polygon(poly, origin, u)
                if t1 - t0 >= min_pass_length]
        return origin, kept

    mid = (lo + hi) / 2.0
    passes = []
    for k, (c, nudge) in enumerate(line_levels):
        if nudge:
            c += FLUSH_INSET_M * nudge            # flush line: just inside the edge
        origin, intervals = clip(c)
        if not intervals and not nudge:
            # an ordinary line that found nothing: nudge it a centimetre toward
            # the middle and try once more, so a pass is never silently dropped
            c += 0.01 if c < mid else -0.01
            origin, intervals = clip(c)
        for t0, t1 in intervals:
            a = g.add(origin, g.scale(u, t0))
            b = g.add(origin, g.scale(u, t1))
            passes.append(Pass(k, a, b, t0, t1, c))
    return passes, u, v


# How much one square metre of ground left unsprayed is "worth", in metres of
# extra flying, when different sweep directions are compared. High on purpose:
# a slightly longer route is always preferred to a strip of field that never
# gets sprayed.
UNCOVERED_PENALTY_M_PER_M2 = 5.0

# How much more a metre of leg 1 (INITIAL -> START) counts than a metre of
# spraying, when START is chosen. Well above 1 on purpose: START should be the
# reachable spray-pattern corner closest to the drone, not just a corner that
# happens to make the rest of the trip a few metres shorter.
LEG1_WEIGHT = 20.0

# A tie-breaker, not a real cost: link_points now always takes the true
# shortest route inside the field (see its docstring), which on an uneven
# field can legitimately cut back across ground already sprayed - that leg
# is flown with the pump OFF, so it wastes no chemical, it just re-uses
# already-flown ground instead of adding a longer walk around the edge. A
# few such crossings are normal and should never outweigh a genuinely
# shorter route. This only nudges the choice between two routes that are
# otherwise close to equal length, toward the visually cleaner one.
CROSSING_TIEBREAK_M = 0.5


def uncovered_area_estimate(passes, field_poly, half_swath, step=0.5):
    """Rough area (m^2) of the field the spray lines would leave unsprayed.

    Only the strip along the field edge can be missed - in the interior the
    lines are never further apart than one swath - so the field is sampled in
    a band 1.5 swaths deep along its boundary, and every sample further than
    half a swath from every spray line counts as missed. Cheap enough to run
    for every candidate sweep direction, and good enough to tell a direction
    that lines up with the field's edges from one that does not.
    """
    import numpy as np
    from matplotlib.path import Path

    if not passes:
        return 0.0
    ring = g.ensure_ccw(g.strip_ring(field_poly))
    n = len(ring)
    depth = max(1.5 * half_swath, 0.1)
    offsets = [depth * f for f in (0.05, 0.25, 0.45, 0.65, 0.85, 0.97)]
    weights = [depth * w for w in (0.10, 0.20, 0.20, 0.20, 0.20, 0.10)]
    pts, wts = [], []
    for i in range(n):
        a, b = ring[i], ring[(i + 1) % n]
        e = g.sub(b, a)
        length = g.norm(e)
        if length < 1e-9:
            continue
        d = (e[0] / length, e[1] / length)
        inward = (-d[1], d[0])                    # left of a CCW edge
        m = max(1, int(ceil(length / step)))
        for j in range(m):
            t = (j + 0.5) * length / m
            for off, wgt in zip(offsets, weights):
                pts.append((a[0] + d[0] * t + inward[0] * off,
                            a[1] + d[1] * t + inward[1] * off))
                wts.append(wgt * length / m)
    if not pts:
        return 0.0
    P = np.asarray(pts)
    W = np.asarray(wts)
    inside = Path(np.array(g.close_ring(ring))).contains_points(P)
    P, W = P[inside], W[inside]

    covered = np.zeros(len(P), dtype=bool)
    for p in passes:
        a = np.asarray(p.a, dtype=float)
        b = np.asarray(p.b, dtype=float)
        ab = b - a
        L2 = float(ab @ ab)
        todo = ~covered
        if not todo.any():
            break
        Q = P[todo]
        tt = np.clip((Q - a) @ ab / L2, 0.0, 1.0) if L2 > 1e-12 else np.zeros(len(Q))
        proj = a + tt[:, None] * ab
        hit = np.linalg.norm(Q - proj, axis=1) <= half_swath
        idx = np.flatnonzero(todo)
        covered[idx[hit]] = True
    return float(W[~covered].sum())


# ---------------------------------------------------------------------------
# 3) boustrophedon cell decomposition
# ---------------------------------------------------------------------------
def build_cells(passes):
    """Split the passes into boustrophedon CELLS.

    A cell is a run of consecutive sweep lines that correspond one-to-one:
    line k has exactly one pass in the cell, and it continues into exactly
    one pass on line k+1. The run is cut wherever the field splits in two or
    two arms merge (the classic "critical points" of a boustrophedon
    decomposition - e.g. where a U-shaped field opens into its two arms).

    This matters because a cell can always be flown as a pure serpentine:
    down one pass, short turn at the edge, back up the next. That is what
    makes the route physically incapable of crossing itself within a cell.
    Flying the raw sweep lines in line order instead - which is what the
    previous planner effectively did - makes the drone jump between the two
    arms of the field on every single line, dragging a long transit across
    the field each time.
    """
    by_line = {}
    for idx, p in enumerate(passes):
        by_line.setdefault(p.k, []).append(idx)

    succ = {i: [] for i in range(len(passes))}
    pred = {i: [] for i in range(len(passes))}
    for k in sorted(by_line):
        if k + 1 not in by_line:
            continue
        for i in by_line[k]:
            for j in by_line[k + 1]:
                if min(passes[i].u1, passes[j].u1) - max(passes[i].u0, passes[j].u0) > 1e-6:
                    succ[i].append(j)
                    pred[j].append(i)

    def starts_a_cell(i):
        if len(pred[i]) != 1:
            return True
        p = pred[i][0]
        return len(succ[p]) != 1

    cells, used = [], set()
    for i in sorted(range(len(passes)), key=lambda x: (passes[x].k, passes[x].u0)):
        if i in used or not starts_a_cell(i):
            continue
        cell, cur = [], i
        while True:
            cell.append(cur)
            used.add(cur)
            if len(succ[cur]) != 1:
                break
            nxt = succ[cur][0]
            if len(pred[nxt]) != 1 or nxt in used:
                break
            cur = nxt
        cells.append(cell)

    # safety net: anything not picked up above becomes its own cell
    for i in range(len(passes)):
        if i not in used:
            cells.append([i])
            used.add(i)

    return [sorted(c, key=lambda x: passes[x].k) for c in cells]


# ---------------------------------------------------------------------------
# 4) chain everything into one continuous, non-self-crossing route
# ---------------------------------------------------------------------------
def _far_point(seg, first_high):
    """A virtual point far past one end of a pass, used only to decide which
    end the very first pass should be entered from."""
    d = g.unit(g.sub(seg.b, seg.a))
    return (g.add(seg.b, g.scale(d, 1e6)) if first_high
            else g.sub(seg.a, g.scale(d, 1e6)))


def link_points(a, b, poly, spacing):
    """Route the drone from a to b by the SHORTEST path that stays inside
    the field.

    Short end-of-row turns are flown straight (they are only one row apart
    and already inside the field). Anything longer is routed with
    `shortest_path_inside`, a visibility-graph shortest path: on a simple,
    convex-ish stretch of field that is a straight line, and on an uneven
    (concave/L/U-shaped) field it takes whichever true-shortest route stays
    inside the boundary - cutting straight across the field when that is
    shorter than following the edge, rather than always detouring around
    the perimeter. The transit leg is flown with the pump OFF, so crossing
    over already-sprayed ground costs nothing but battery/time, and the
    planner's crossing penalty (see build_coverage_route) still discourages
    routes that tangle badly.
    """
    if g.dist(a, b) <= 2.5 * spacing and g.segment_inside_polygon(a, b, poly, tol=1e-3):
        return [a, b]

    route = g.shortest_path_inside(a, b, poly)
    return g.dedupe_consecutive(route)


def _chain_cell(cell, passes, poly, spacing, current, line_desc, first_high):
    """Fly one cell as a serpentine. Returns (points, flags, end_point) where
    flags[i] says whether the leg INTO points[i] is sprayed."""
    segs = [passes[i] for i in cell]
    segs.sort(key=lambda s: s.k, reverse=line_desc)

    if current is None:
        current = _far_point(segs[0], first_high)

    pts, flags = [], []
    for seg in segs:
        entry, exit_ = ((seg.a, seg.b)
                        if g.dist(current, seg.a) <= g.dist(current, seg.b)
                        else (seg.b, seg.a))
        if pts:
            link = link_points(current, entry, poly, spacing)
            for p in link[1:]:
                pts.append(p)
                flags.append(False)   # repositioning: pump OFF
        else:
            pts.append(entry)
            flags.append(False)
        pts.append(exit_)
        flags.append(True)            # the pass itself: pump ON
        current = exit_
    return pts, flags, current


def _cell_points(cell, passes):
    out = []
    for i in cell:
        out.append(passes[i].a)
        out.append(passes[i].b)
    return out


def _order_cells(cells, passes, first):
    """`first` (an index into `cells`) is flown first; after that, always hop
    to whichever remaining cell is closest to where we just finished."""
    remaining = [c for i, c in enumerate(cells) if i != first]
    ordered = [cells[first]]
    cursor = _cell_points(cells[first], passes)[-1]
    while remaining:
        nxt = min(remaining, key=lambda c: min(g.dist(cursor, p) for p in _cell_points(c, passes)))
        remaining.remove(nxt)
        ordered.append(nxt)
        cursor = _cell_points(nxt, passes)[-1]
    return ordered


def _dedupe_with_flags(pts, flags, tol=1e-6):
    out_p, out_f = [], []
    for p, f in zip(pts, flags):
        if out_p and g.dist(out_p[-1], p) <= tol:
            out_f[-1] = out_f[-1] or f
            continue
        out_p.append(p)
        out_f.append(f)
    if out_f:
        out_f[0] = False
    return out_p, out_f


def _build_route_for_angle(poly, spacing, passes, cells, first_cell, first_high, line_desc):
    ordered = _order_cells(cells, passes, first_cell)

    pts, flags, current = [], [], None
    for ci, cell in enumerate(ordered):
        sub_pts, sub_flags, current = _chain_cell(
            cell, passes, poly, spacing, current if ci else None, line_desc, first_high
        )
        if pts and sub_pts:
            link = link_points(pts[-1], sub_pts[0], poly, spacing)
            for p in link[1:-1]:
                pts.append(p)
                flags.append(False)
        pts.extend(sub_pts)
        flags.extend(sub_flags)

    pts, flags = _dedupe_with_flags(pts, flags)
    if len(pts) < 2:
        return None
    return {"points": pts, "flags": flags, "length_m": g.polyline_length(pts)}


def _reverse_route(pts, flags):
    """Fly the same route backwards. flags[i] is the spray state of the leg
    INTO point i, so the flags have to be re-indexed, not just reversed."""
    n = len(pts)
    return pts[::-1], [False] + [flags[n - j] for j in range(1, n)]


def build_coverage_route(poly, spacing, angle, initial, transit_out_cost,
                         turn_penalty_m=10.0, prune_above=float("inf"),
                         max_first_cells=6, field_poly=None, swath=None):
    """Build the best START -> GOAL spraying route for ONE fixed sweep angle.

    START and GOAL are not given - they are the two ends of the route, and
    every way of laying the route down is tried:

        * sweep the lines in either order            (2)
        * enter the first pass from either end       (2)
        * begin in each cell of the field            (up to `max_first_cells`,
                                                      nearest the drone first)
        * fly the finished route forwards OR backwards

    Each candidate is scored on the WHOLE mission the drone will fly:

        leg 1 (INITIAL -> START, weighted x LEG1_WEIGHT)  +  spraying route
        +  turn penalty
        +  leg 3 (GOAL -> INITIAL, the straight shortest line)
        +  a small tie-break for self-crossings (CROSSING_TIEBREAK_M) - it
           only decides between two routes of near-identical length, it
           never overrides a genuinely shorter route

    and the cheapest one wins, so START and GOAL are always real corners of
    the real spray pattern, placed wherever makes the whole trip shortest.

    `transit_out_cost(start_xy)` must return the length of leg 1 to a given
    START (the planner supplies it so leg 1 is measured exactly as it will
    be flown). `prune_above` lets the caller skip work on candidates that
    already cannot beat the best route found at other angles.
    """
    passes, _, _ = build_passes(poly, spacing, angle)
    if not passes:
        raise ValueError(
            "No spray lines fit inside this field. The field may be smaller "
            "than the safety margin, or the spray swath width may be too large."
        )
    cells = build_cells(passes)
    num_segments = len(passes)
    used = sorted({round(p.c, 6) for p in passes})
    gaps = [b - a for a, b in zip(used, used[1:])] or [spacing]
    angle_cost = turn_penalty_m * max(0, num_segments - 1)      # same for every arrangement
    if field_poly is not None:
        missed = uncovered_area_estimate(passes, field_poly, (swath or spacing) / 2.0)
        angle_cost += UNCOVERED_PENALTY_M_PER_M2 * missed

    rank = sorted(range(len(cells)),
                  key=lambda i: min(g.dist(initial, p) for p in _cell_points(cells[i], passes)))
    first_cells = rank[:max(1, max_first_cells)]

    best = None
    bound = prune_above
    for first_cell in first_cells:
        for line_desc in (False, True):
            for first_high in (False, True):
                r = _build_route_for_angle(poly, spacing, passes, cells,
                                           first_cell, first_high, line_desc)
                if r is None:
                    continue
                pts, flags = r["points"], r["flags"]

                fwd = LEG1_WEIGHT * transit_out_cost(pts[0]) + g.dist(pts[-1], initial)
                rev = LEG1_WEIGHT * transit_out_cost(pts[-1]) + g.dist(pts[0], initial)
                backwards = rev < fwd - 1e-9
                base = r["length_m"] + angle_cost + (rev if backwards else fwd)
                if base >= bound - 1e-9:
                    continue                      # crossings can only add cost

                crossings = g.count_self_crossings(pts)
                cost = base + CROSSING_TIEBREAK_M * crossings
                if cost >= bound - 1e-9:
                    continue
                if backwards:
                    pts, flags = _reverse_route(pts, flags)
                bound = cost
                best = {
                    "points": pts,
                    "flags": flags,
                    "start": pts[0],
                    "goal": pts[-1],
                    "num_passes": len({p.k for p in passes}),
                    "num_segments": num_segments,
                    "num_cells": len(cells),
                    "angle_deg": (degrees(angle) % 180.0),
                    "length_m": r["length_m"],
                    "spacing_min_m": min(gaps),
                    "spacing_max_m": max(gaps),
                    "crossings": crossings,
                    "mission_cost": cost,
                }
    return best


def plan_coverage(poly, spacing, initial, transit_out_cost, mode="auto",
                  fixed_angle_deg=0.0, turn_penalty_m=10.0, max_candidate_angles=10,
                  field_poly=None, swath=None):
    """Choose the sweep direction, START, GOAL and the route between them.

    In "auto" mode every candidate direction (one per edge of the field's
    convex hull) is actually planned - with every START/GOAL arrangement
    described in build_coverage_route - and the cheapest whole mission wins.
    Picking purely by "fewest passes", as a naive planner does, can pick a
    direction that then forces the drone to shuttle back and forth between
    separated parts of the field. Each direction is also charged for any ground
    along the field edge its lines would leave unsprayed (pass `field_poly` and
    `swath`), so a direction whose lines run parallel to the field's edges wins
    over a marginally shorter one that leaves strips unsprayed.
    """
    if mode == "angle":
        angles = [radians(fixed_angle_deg)]
    else:
        angles = candidate_angles(poly, max_candidate_angles)

    best, bound = None, float("inf")
    for ang in angles:
        try:
            r = build_coverage_route(poly, spacing, ang, initial, transit_out_cost,
                                     turn_penalty_m, prune_above=bound,
                                     field_poly=field_poly, swath=swath)
        except ValueError:
            continue
        if r is not None and r["mission_cost"] < bound:
            best, bound = r, r["mission_cost"]

    if best is None:
        raise ValueError(
            "No spray lines fit inside this field. The field may be smaller "
            "than the safety margin, or the spray swath width may be too large."
        )
    return best


def candidate_angles(poly, limit):
    """Directions worth trying: one per convex-hull edge (that is where an
    optimal sweep direction always lies), deduplicated modulo 180 degrees."""
    hull = g.convex_hull(g.strip_ring(poly))
    raw = []
    for i in range(len(hull)):
        a, b = hull[i], hull[(i + 1) % len(hull)]
        e = g.unit(g.sub(b, a))
        if e == (0.0, 0.0):
            continue
        ang = atan2(e[1], e[0]) % pi
        v = (-e[1], e[0])
        projs = [g.dot(p, v) for p in hull]
        raw.append((max(projs) - min(projs), ang))

    seen, out = [], []
    for width, ang in sorted(raw):
        if any(min(abs(ang - s), pi - abs(ang - s)) < radians(2.0) for s in seen):
            continue
        seen.append(ang)
        out.append(ang)
        if len(out) >= limit:
            break
    return out or [0.0]
