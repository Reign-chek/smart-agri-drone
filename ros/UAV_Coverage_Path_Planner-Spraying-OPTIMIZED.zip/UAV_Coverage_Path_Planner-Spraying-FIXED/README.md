# UAV Coverage Path Planner - Full-Field Spraying Edition

Generates a clean, gap-free spray flight path for a field you trace in
**Google Earth**, and exports GPS waypoints for the drone plus a colour-coded
KML you can preview back in Google Earth.

## The mission, and how it is drawn

Nothing about the mission is hard-coded. You give the program **a field** and
**the drone's position**; it works out the best START, the best GOAL and the
whole path, then writes the GPS coordinates of every leg. Every mission has
exactly three legs, coloured the same way in the preview image and in Google
Earth:

| Element | Colour | Meaning |
|---|---|---|
| Field boundary | **black** | the edge of the field, as you traced it |
| INITIAL | **black square** | the drone's position - you enter it when the program asks (launch & landing) |
| Leg 1: INITIAL -> START | **green** | transit out, pump OFF |
| START | **red dot** | spraying begins - chosen by the planner |
| Leg 2: START -> GOAL | **blue** | the coverage pass, pump ON |
| GOAL | **yellow dot** | spraying ends - chosen by the planner |
| Leg 3: GOAL -> INITIAL | **green** | transit home, pump OFF - always the straight, shortest line, even across the field |
| repositioning inside the field | **orange** | pump OFF while moving between parts of the pattern |

No two elements share a colour, so the boundary can never be mistaken for the
flight path.

## How START, GOAL and the path are chosen

The planner scores the **whole trip** the drone will fly:

```
leg 1 (INITIAL -> START)  +  spraying route  +  turn penalty
  +  leg 3 (GOAL -> INITIAL, straight line)  +  penalty for any self-crossing
```

and keeps the cheapest. To find it, it tries every sweep direction, both
directions of travel along the lines, every end the first pass can be entered
from, each cell of the field as the place to begin (nearest the drone first),
and the finished route flown forwards *and* backwards. START and GOAL are
therefore always real corners of the real spray pattern, and they move
depending on where the drone is: put the drone on the other side of the field
and START and GOAL swap or shift accordingly.

Leg 1 is counted `LEG1_WEIGHT` (20) times over in that score (`coverage.py`).
Without that weight the planner cannot tell "START near you, GOAL far away" from
"START far away, GOAL near you" - the two cost the same - and would sometimes
pick the far START. With it, START is the reachable corner of the spray pattern
closest to the drone. (START can only be an end of the first or last pass of a
cell, because the serpentine has to be flown in order.)

- **Leg 1** (INITIAL -> START) is the straight, shortest line by default; set `TRANSIT_AVOID_FIELD = True` to fly around the field instead.
- **Leg 3** (GOAL -> INITIAL) is always the direct, shortest line home. It is
  allowed to cross the field - the drone is not spraying, and a detour would
  only cost battery.
- The spray pattern itself (swath, overlap, spacing, safety margin, turn
  penalty, sweep mode) is exactly as configured in `config.py`.

## What was fixed in the previous version

**The path used to cross itself.** The old planner split the field into convex
cells and ran a *separate* lawnmower inside each one, each cell choosing its
own line direction, then joined the cells with a grid A\* route that was free
to cut diagonally back across ground it had already sprayed. That produced the
long streak through the middle of the pattern and the knot of crossing lines.

It now works the other way round:

1. **One sweep direction for the whole field.** Every sensible direction is
   tried, the *complete* route is planned for each, and the cheapest wins -
   scored on flown distance, plus a penalty for each end-of-row turn, plus a
   heavy penalty for any self-crossing.
2. **Proper boustrophedon cells.** The passes are cut into runs of sweep lines
   that correspond one-to-one, split at the points where the field genuinely
   divides (e.g. where a U-shaped field opens into its two arms). Each such
   cell is flown as a pure serpentine, which physically cannot cross itself.
3. **Repositioning follows the boundary.** Every spray pass ends on the field's
   safety boundary, so a move that walks along that boundary can only touch the
   *ends* of other passes - it can never cut across them. Short end-of-row
   turns are still flown straight.
4. **The outbound transit goes around the outside.** Leg 1 routes around the
   field and enters at the nearest edge, so it never slices through the
   pattern. (Leg 3, the way home, is now the straight shortest line.)

**START and GOAL were not clearly defined.** They used to be your config
coordinates snapped onto the boundary, which had nothing to do with where the
spray pattern actually began or ended - hence the long leg across the field to
reach them. They are now **real corners of the real spray pattern**, chosen by
the planner (see above - they are no longer typed in at all).

**Boundary and path were the same colour in Google Earth.** The old KML drew
the field boundary in blue *and* the spraying leg in blue. See the colour table
above. The `coverage_cells.kml` output, which drew extra coloured polygons over
your field, has been dropped.

Two further changes worth knowing about:

- **Pump state is tracked per waypoint.** End-of-row turns and repositioning
  moves are marked `OFF` in `waypoints_gps.txt`. That ground is already covered
  by the adjacent passes' swaths, so spraying through the turns was
  over-applying at the headlands.
- **Coverage is measured, not assumed.** After planning, the finished path is
  sampled on a grid and checked against the real spray swath. The result is
  printed and written into `drone_and_spray_specs.txt`. The outermost passes
  are also now placed flush against the safety boundary - centring the block,
  as before, could leave a strip along the field edge unsprayed.

## Full-field coverage: how the line spacing is fitted

The drone flies along the **centre** of its spray swath, so with the 1.5 m
drone in `config.py`:

- the first and last line sit **0.75 m** (half a swath) from the field edge, so
  the outer edge of the spray lands exactly on the boundary;
- neighbouring lines are **never more than 1.5 m** apart.

A field is rarely an exact multiple of 1.5 m wide, so the planner adjusts the
gap instead of leaving a strip unsprayed or spraying past the edge. Between two
fixed lines a distance `G` apart it uses `n = ceil(G / 1.5)` equal steps of
`G / n` (always <= 1.5 m). Example: 10.3 m between the outer lines gives
`ceil(10.3 / 1.5) = 7` steps of 1.471 m.

This is done **band by band**, not once for the whole field. A fixed line is
also placed on every interior wall that runs parallel to the lines - the inner
wall of an L-shaped field, the two inner walls of a U - so each arm is fitted on
its own and its edge strip is covered too. When several sweep directions are
compared, a direction that would leave strips along the edge unsprayed is
penalised (`UNCOVERED_PENALTY_M_PER_M2` in `coverage.py`).

The actual gap used is printed while planning and written to
`drone_and_spray_specs.txt` ("Adjusted spacing used").

**What can still be missed.** The drone must stay 0.75 m inside the boundary, so
where a spray line *ends* at the edge, the round-off between two neighbouring
line ends is not reached, and an edge that is neither parallel nor at right
angles to the lines leaves a little more. The "Field covered" figure in the
specs file is measured with a round footprint (the strictest reading) and shows
that residue - typically 1-3 % on a rectangle or L/U shape.

## 1. Get your field boundary from Google Earth

1. Open Google Earth ([web](https://earth.google.com/web) or desktop).
2. Fly to your field, use the **Add Polygon** tool, and click each corner to
   trace the outline.
3. Save the shape.
4. **Optional:** with the **Add Placemark** tool, drop one pin named exactly
   `INITIAL` where the drone is. The program asks for the drone's position
   when it runs, and offers this pin as the default answer. Do not mark START
   or GOAL - the planner chooses those (any such pins are ignored).
5. Right-click the project in *Projects* / *My Places* and choose
   **Export as KML File...**.

When you later open `outputs/spray_path.kml`, untick your original traced
polygon in the sidebar - otherwise Google Earth draws its own blue outline on
top of the black one from this tool.

## 2. Configure

Open `config.py`:

- `INPUT_FIELD_KML` - default field file offered at the upload prompt.
- `SPRAY_SWATH_WIDTH_M` - the width your sprayer actually wets in one pass.
  This is the single most important number for full coverage; measure it on
  the ground if unsure. It equals the drone's width, and half of it is the
  distance kept from the field boundary (`BOUNDARY_SAFETY_MARGIN_M`).
- `SPRAY_OVERLAP_PCT` - overlap between adjacent passes (`0.15` = 15%).
- `PATH_STEP_M` - distance between the GPS points in `full_path_gps.csv` (default 1 m).
- `SAVE_ANIMATION`, `ANIMATION_FRAMES` - turn the animated GIF on/off and set how many
  frames it has (default 240, played at 20 frames per second).

### Choosing the direction of the spray lines

`SWEEP_MODE = "auto"` (the default) lets the planner choose. It will normally
pick long passes along the field's longest axis, because fewer end-of-row turns
means a shorter path and fewer places to over-apply.

If your crop is planted in rows and you must fly **along** the rows, override it:

```python
SWEEP_MODE = "angle"
SWEEP_ANGLE_DEG = 90     # 0 = lines run East-West, 90 = North-South
```

`TURN_PENALTY_M` controls how hard "auto" leans toward fewer turns. Set it to
`0` to judge purely on flown distance.

### Transit legs

`TRANSIT_AVOID_FIELD = False` (the default) flies leg 1 (out to the field) as the
straight, shortest line to START. Set it to `True` to route around the outside
of the field, `TRANSIT_CLEARANCE_M` away from it, at the cost of a longer leg.
Leg 3 (home) is not affected: it is always the straight, shortest line.

`TRANSIT_WAYPOINT_SPACING_M` (default `10.0`) sets how far apart the
intermediate GPS waypoints are along legs 1 and 3. Set it to `0` to get only
the corner points (leg 3 is then just GOAL and the drone's position).

## 3. Install and run

```bash
pip install -r requirements.txt
python uav_spray_path_planner.py
```

The program asks two things:

1. **Your field** - a file-picker opens so you can upload your `.kml` (or type
   the path if you are running headless - press Enter to use the bundled
   sample field).
2. **The drone's position** - type it as decimal degrees, latitude first, e.g.
   `-17.8252, 31.0335` (or `17.8252 S, 31.0335 E`). If your KML has a pin named
   `INITIAL`, just press Enter to use it. A position more than 5 km from the
   field is queried before it is accepted, which catches a swapped
   latitude/longitude.

The planner then chooses START, GOAL and the path, and the preview image opens
automatically when planning is done.

This version needs only **numpy, matplotlib and scipy** - `shapely` and
`simplekml` are no longer required. The geometry is done by `geometry.py` and
the KML is written directly, which is what allows the exact control over
colours and styling described above.

## 4. What you get

```
outputs/
  full_path_gps.csv          the WHOLE trip, INITIAL -> ... -> INITIAL, a GPS point every PATH_STEP_M
  spray_path.kml             colour-coded mission, for Google Earth
  waypoints_gps.txt          GPS waypoints in flight order, with a SPRAY column
  leg1_initial_to_start.csv  GPS coordinates: drone position -> START
  leg2_start_to_goal.csv     GPS coordinates: START -> GOAL (with SPRAY ON/OFF)
  leg3_goal_to_initial.csv   GPS coordinates: GOAL -> drone position
  drone_and_spray_specs.txt  parameters used + measured coverage + summary
  path_preview.png           preview image
  path_animation.gif         animation of the drone flying the whole mission
```

`full_path_gps.csv` is the file the drone follows and compares its own GPS
position against. It lists every point of the trip in order - out to START, the
whole spray path, back from GOAL to INITIAL - with a coordinate at least every
`PATH_STEP_M` (default 1 m) along it, corners kept exactly. Columns:

```
STEP, LATITUDE, LONGITUDE, SPRAY, LEG, POINT, CUM_DIST_M
```

`POINT` is `INITIAL`, `START` or `GOAL` on those rows and empty elsewhere;
`CUM_DIST_M` is the distance flown along the path up to that point.

`waypoints_gps.txt` columns:

```
WP, LATITUDE, LONGITUDE, SPRAY, LEG, CUM_DIST_M
```

`SPRAY` is `ON` or `OFF` for the leg leading *into* that waypoint, so a flight
controller can drive the pump straight from the file.

The three `leg*.csv` files hold the same coordinates split by leg, so the drone
can be given exactly the GPS points to fly for each part of the mission. Each
leg starts where the previous one ended (leg 1 ends at START, which is where
leg 2 begins; leg 2 ends at GOAL, which is where leg 3 begins; leg 3 ends back
at the drone's position). Columns:

```
WP, LATITUDE, LONGITUDE, SPRAY, CUM_DIST_M
```

The two transit legs (1 and 3) carry **intermediate GPS waypoints**: every
straight stretch is broken into hops of at most `TRANSIT_WAYPOINT_SPACING_M`
(default 10 m), so the drone has a GPS point to match every few meters instead
of one point hundreds of meters away. Corners of the route are always kept.
The spray passes are not subdivided in these files; `full_path_gps.csv` is the
one that subdivides everything.

Check `drone_and_spray_specs.txt` for the important numbers:

```
Path self-crossings         : 0      (0 = fully clean path)
Field covered               : 99.68 %
Over-sprayed (3+ passes)    : 0.00 %
```

"Over-sprayed" counts ground hit by three or more passes. Two passes
overlapping is intended - that is what `SPRAY_OVERLAP_PCT` is for - so only 3+
is treated as waste. A "field covered" figure slightly under 100% is normal:
it is the sliver in sharp corners that the boundary safety margin keeps the
drone out of.

## Files in this project

- `config.py` - all user-editable settings.
- `uav_spray_path_planner.py` - the planner; run this file. Asks for the field and the drone's position.
- `coverage.py` - sweep direction, boustrophedon cells, serpentine routing, and the choice of START / GOAL.
- `geometry.py` - polygon maths (inset/outset, clipping, visibility routing).
- `kml_writer.py` - the colour-coded Google Earth output.
- `verify.py` - the measured coverage / over-spray check.
- `path_animation.py` - renders `path_animation.gif`: the drone flying INITIAL -> START -> spray path -> GOAL -> INITIAL, leaving a coloured trail (green transit, blue spraying with the sprayed ground shaded to the real swath width, orange repositioning), with the leg, distance and pump state shown.
- `geo_utils.py` - GPS <-> local-meters conversion.
- `sample_field.kml` - an example field so you can try it immediately.

## Tuning tips

- If the pattern looks too sparse or too dense, fix `SPRAY_SWATH_WIDTH_M` and
  `SPRAY_OVERLAP_PCT` first - everything else is derived from them.
- If the planner says the safety margin is too large for the field, reduce
  `SPRAY_SWATH_WIDTH_M` (the margin is half of it), or check that your traced
  polygon does not cross over itself.
- If "Path self-crossings" is ever above 0, that is worth reporting - on
  ordinary field shapes it should be exactly 0.
