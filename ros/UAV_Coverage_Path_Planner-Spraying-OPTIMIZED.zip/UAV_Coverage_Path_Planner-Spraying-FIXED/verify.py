"""
verify.py
---------
Independent check on the generated mission. Rather than trusting that the
spacing maths worked out, this measures the finished path:

  * COVERAGE  - what fraction of the field actually falls under the spray
                swath of at least one pass.
  * DOUBLING  - what fraction gets covered by three or more passes, i.e.
                where chemical is genuinely being wasted. (Two passes
                overlapping is intended - that is what SPRAY_OVERLAP_PCT is
                for - so only 3+ is counted as over-application.)

Both are computed by sampling the field on a regular grid and measuring the
distance from each sample to every sprayed segment, with numpy doing the
heavy lifting.
"""

import numpy as np

import geometry as g


def _sample_points(poly, step):
    from matplotlib.path import Path

    minx, miny, maxx, maxy = g.bounds(poly)
    xs = np.arange(minx + step / 2, maxx, step)
    ys = np.arange(miny + step / 2, maxy, step)
    if xs.size == 0 or ys.size == 0:
        return np.empty((0, 2))
    gx, gy = np.meshgrid(xs, ys)
    pts = np.column_stack([gx.ravel(), gy.ravel()])
    inside = Path(np.array(g.close_ring(poly))).contains_points(pts)
    return pts[inside]


def _segment_distances(pts, a, b):
    """Distance from every sample point to one segment."""
    ab = b - a
    L2 = float(ab @ ab)
    if L2 < 1e-12:
        return np.linalg.norm(pts - a, axis=1)
    t = np.clip((pts - a) @ ab / L2, 0.0, 1.0)
    proj = a + t[:, None] * ab
    return np.linalg.norm(pts - proj, axis=1)


def verify_coverage(field_poly, points, flags, swath_width_m, step=None):
    """Returns a dict of coverage statistics for the sprayed legs only."""
    half = swath_width_m / 2.0
    step = step or max(0.5, swath_width_m / 4.0)

    samples = _sample_points(field_poly, step)
    if samples.shape[0] == 0:
        return {"samples": 0, "covered_pct": 0.0, "triple_pct": 0.0, "step_m": step}

    hits = np.zeros(samples.shape[0], dtype=np.int16)
    for i in range(1, len(points)):
        if not flags[i]:
            continue  # pump was off on this leg - it sprays nothing
        a = np.asarray(points[i - 1], dtype=float)
        b = np.asarray(points[i], dtype=float)
        hits += (_segment_distances(samples, a, b) <= half).astype(np.int16)

    n = samples.shape[0]
    return {
        "samples": int(n),
        "step_m": step,
        "covered_pct": float((hits >= 1).sum()) / n * 100.0,
        "triple_pct": float((hits >= 3).sum()) / n * 100.0,
        "mean_passes": float(hits.mean()),
    }
