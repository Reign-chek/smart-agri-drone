"""
kml_writer.py
-------------
Writes the mission out as KML for Google Earth, with a deliberately
high-contrast colour scheme:

    field boundary .............. BLACK outline, no fill
    transit legs (to/from pad) ... GREEN
    spraying pass ................ BLUE
    in-field repositioning ....... ORANGE (pump off, e.g. rounding a notch)
    INITIAL (launch & land) ...... BLACK square marker
    START  (spraying begins) ..... RED marker
    GOAL   (spraying ends) ....... YELLOW marker

The old version drew the field boundary in blue AND the spray path in blue,
which is why the boundary and the path were impossible to tell apart in
Google Earth. Nothing here reuses a colour.

KML colours are written as aabbggrr (alpha, blue, green, red) - NOT the
rrggbb you may be used to.
"""

BLACK = "ff000000"
ORANGE = "ff0080ff"
BLUE = "ffff0000"
GREEN = "ff00ff00"
RED = "ff0000ff"
YELLOW = "ff00ffff"
WHITE = "ffffffff"

ICON_SQUARE = "http://maps.google.com/mapfiles/kml/paddle/wht-square.png"
ICON_CIRCLE = "http://maps.google.com/mapfiles/kml/paddle/wht-circle.png"


def _esc(text):
    return (str(text).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _coord_block(coords, indent="          "):
    return "\n".join(f"{indent}{lon:.8f},{lat:.8f},0" for lon, lat in coords)


def _line_style(style_id, color, width):
    return f"""    <Style id="{style_id}">
      <LineStyle><color>{color}</color><width>{width}</width></LineStyle>
      <PolyStyle><fill>0</fill><outline>1</outline></PolyStyle>
    </Style>"""


def _icon_style(style_id, href, color, scale=1.1):
    return f"""    <Style id="{style_id}">
      <IconStyle>
        <color>{color}</color>
        <scale>{scale}</scale>
        <Icon><href>{href}</href></Icon>
        <hotSpot x="32" y="1" xunits="pixels" yunits="pixels"/>
      </IconStyle>
      <LabelStyle><color>{color}</color><scale>1.0</scale></LabelStyle>
    </Style>"""


def _linestring(name, style_id, coords, description=""):
    if len(coords) < 2:
        return ""
    return f"""      <Placemark>
        <name>{_esc(name)}</name>
        <description>{_esc(description)}</description>
        <styleUrl>#{style_id}</styleUrl>
        <LineString>
          <tessellate>1</tessellate>
          <altitudeMode>clampToGround</altitudeMode>
          <coordinates>
{_coord_block(coords)}
          </coordinates>
        </LineString>
      </Placemark>"""


def _point(name, style_id, lonlat, description=""):
    lon, lat = lonlat
    return f"""      <Placemark>
        <name>{_esc(name)}</name>
        <description>{_esc(description)}</description>
        <styleUrl>#{style_id}</styleUrl>
        <Point>
          <altitudeMode>clampToGround</altitudeMode>
          <coordinates>{lon:.8f},{lat:.8f},0</coordinates>
        </Point>
      </Placemark>"""


def write_mission_kml(
    path,
    boundary_lonlat,
    leg_out_lonlat,
    spray_runs,  # list of (spray_on, [(lon,lat), ...]) in flight order
    leg_home_lonlat,
    initial_lonlat,
    start_lonlat,
    goal_lonlat,
    summary="",
):
    """Write the complete mission. Every element gets its own colour so the
    boundary, the two transit legs and the spraying pass never blend."""
    parts = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<kml xmlns="http://www.opengis.net/kml/2.2">',
        "  <Document>",
        "    <name>UAV Spray Mission</name>",
        f"    <description>{_esc(summary)}</description>",
        _line_style("boundary", BLACK, 4),
        _line_style("transit", GREEN, 4),
        _line_style("spray", BLUE, 3),
        _line_style("reposition", ORANGE, 3),
        _icon_style("ptInitial", ICON_SQUARE, BLACK, 1.2),
        _icon_style("ptStart", ICON_CIRCLE, RED, 1.3),
        _icon_style("ptGoal", ICON_CIRCLE, YELLOW, 1.3),
        "    <Folder><name>1 - Field boundary (black)</name>",
        _linestring("Field boundary", "boundary", list(boundary_lonlat),
                    "The edge of the field, as traced in Google Earth."),
        "    </Folder>",
        "    <Folder><name>2 - Flight path</name>",
        _linestring("Leg 1: INITIAL to START (transit, green)", "transit", leg_out_lonlat,
                    "Flying out to the field. No spraying on this leg."),
        *[_linestring(
            f"Leg 2.{i+1}: {'spraying (blue)' if on else 'repositioning, pump OFF (orange)'}",
            "spray" if on else "reposition", run,
            "Spray ON." if on else "Moving between parts of the pattern - pump OFF.")
          for i, (on, run) in enumerate(spray_runs)],
        _linestring("Leg 3: GOAL to INITIAL (transit, green)", "transit", leg_home_lonlat,
                    "Flying home to land. No spraying on this leg."),
        "    </Folder>",
        "    <Folder><name>3 - Mission points</name>",
        _point("INITIAL - launch and land", "ptInitial", initial_lonlat,
               "Take-off and landing pad. Black square."),
        _point("START - spraying begins", "ptStart", start_lonlat,
               "Spray ON here. Red marker."),
        _point("GOAL - spraying ends", "ptGoal", goal_lonlat,
               "Spray OFF here, then fly home. Yellow marker."),
        "    </Folder>",
        "  </Document>",
        "</kml>",
    ]
    with open(path, "w") as fh:
        fh.write("\n".join(p for p in parts if p) + "\n")
